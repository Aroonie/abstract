<?php
  $json = json_decode(file_get_contents('http://178.62.29.135/api/nowplaying/2'), TRUE);
  $art = $json["now_playing"]["song"]["art"];
  $song = $json["now_playing"]["song"]["text"];

  // stupid art shit -- start
  $split = explode(" - ", $song);
    $splitArtist = $split[0];
    $splitSong = $split[1];
    $newArtist = rawurlencode($splitArtist);
    $newTitle = rawurlencode($splitSong);
    $url = 'https://api.deezer.com/2.0/search?q='.$newArtist.'+'.$newTitle.'';
    $urlUNI = str_replace("'", "%27", $url);
    $deezerjson = json_decode(file_get_contents($urlUNI), TRUE);
    $art = $deezerjson['data'][0]['album']['cover'];
    // stupid art shit -- end
    if(empty($art)){
      $art = "https://cdn.discordapp.com/attachments/632915547826290688/634652284260974592/ABSTRACT1.2.png";
    }


  echo '<div class="bg" style="background-image: url(\''.$art.'\')"></div>';
