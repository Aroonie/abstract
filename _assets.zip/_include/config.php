<?
$servername = "localhost";
$username = "weareabs_zen";
$db_name = "weareabs_zen";
$password = "abstract123";
$sql = new mysqli($servername, $username, $password, $db_name) or die("Connect failed: %s\n". $sql -> error);