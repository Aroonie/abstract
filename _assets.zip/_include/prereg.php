<?
include('config.php');
$name = $_POST['name'];
$email = $_POST['email'];
$pass = $_POST['pass'];
$passconfirm = $_POST['passconfirm'];
$userip = $_SERVER['HTTP_CF_CONNECTING_IP'];

if($_POST['name'] && $_POST['email'] && $_POST['pass'] && $_POST['passconfirm']){
  if(strlen($_POST['name']) > 16){
    header('HTTP/1.1 500 Internal Server Error');
    exit('That username is too long (MAX: 16)');
  }else{
    if($name == "" || $pass == "" || $name == " " || $pass == " " || !preg_match('/^[a-zA-Z]+[a-zA-Z0-9._]+$/', $name)){
      header('HTTP/1.1 500 Internal Server Error');
      exit('Your name or password is invalid.');
}else{
  if($pass == $passconfirm){
    $countQuery = $sql->prepare("SELECT * FROM `pre_reg` WHERE `username` = ?");
    $countQuery->bind_param("s", $name);
    $countQuery->execute();
    $countQuery = $countQuery->get_result();
    $countrow = mysqli_num_rows($countQuery);

    if($countrow > 0){
      header('HTTP/1.1 500 Internal Server Error');
      exit('That username has been taken!');
    }else{
      if (preg_match('/^[a-zA-Z]+[a-zA-Z0-9._]+$/', $name)){
        $password = password_hash($pass, PASSWORD_DEFAULT);
        $pre = $sql->prepare("INSERT INTO `pre_reg` (`username`, `password`, `email`, `ip`) VALUES (?, ?, ?, ?)");
        $pre->bind_param("ssss", $name, $password, $email, $userip);
        $pre->execute();
        session_start();
        $_SESSION['reg'] = TRUE;
      }
    }
  }else{
    header('HTTP/1.1 500 Internal Server Error');
    exit('The passwords do not match');
  }
}
}

}else{
  header('HTTP/1.1 500 Internal Server Error');
  exit('You must set all fields.');
}
