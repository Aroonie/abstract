<?
$username = basename($_POST['username']);
$content = basename($_POST['content']);
$type = basename($_POST['type']);

if(!isset($_POST['username']) || !isset($_POST['content']) || !isset($_POST['type'])){
  header('HTTP/1.1 500 Internal Server Error');
  exit('You must set all fields.');
}else{

$url = "https://discordapp.com/api/webhooks/638707478762094593/V81aPtr5J5TICfhUhVNvXHij5YS3rHw-YQ9_MHIujJ7rAK5l7jiCiRigC_lmF6SsEfoZ";
$hookObject = json_encode([
    "content" => "**A NEW REQUEST HAS BEEN RECIEVED!** :tada:",
    "username" => "Abstract",
    "avatar_url" => "https://cdn.discordapp.com/attachments/632915547826290688/634652284260974592/ABSTRACT1.2.png",
    "tts" => false,
    "embeds" => [
        [
            "title" => "",
            "type" => "rich",
            "description" => "",
            "color" => hexdec( "FF69B4" ),
            "fields" => [
                [
                    "name" => "User",
                    "value" => $username,
                    "inline" => false
                ],
                [
                    "name" => "Content",
                    "value" => $content,
                    "inline" => true
                ],
                [
                    "name" => "Type",
                    "value" => $type,
                    "inline" => true
                ]
            ]
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

$ch = curl_init();

curl_setopt_array( $ch, [
    CURLOPT_URL => $url,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $hookObject,
    CURLOPT_HTTPHEADER => [
        "Length" => strlen( $hookObject ),
        "Content-Type" => "application/json"
    ]
]);

$response = curl_exec( $ch );
curl_close( $ch );

}
?>
