<div class="modal fade" id="preregister-modal" tabindex="-1" role="dialog" aria-labelledby="preregister-modal-label" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="preregister-modal-label">Pre Register</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="prereg">
          <input id="name" <?if($_SESSION['reg']){echo'disabled';}?> placeholder="Username"/> <input id="email" <?if($_SESSION['reg']){echo'disabled';}?>  placeholder="Email"/>
          <input id="pass" <?if($_SESSION['reg']){echo'disabled';}?>  type="password" placeholder="Password"/> <input id="passconfirm" <?if($_SESSION['reg']){echo'disabled';}?>  type="password" placeholder="Confirm Password"/>

        </form>
        <button class="reg-button" <?if($_SESSION['reg']){echo'disabled';} if(!$_SESSION['reg']){echo'onclick="preRegister()"';}?>><?if($_SESSION['reg']){echo'You\'re already pre registered';}else{echo'Pre Register';}?></button>
      </div>
    </div>
  </div>
</div>




<div class="modal fade" id="request-modal" tabindex="-1" role="dialog" aria-labelledby="request-modal-label" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="request-modal-label">Request</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="request">
          <input id="req-username" placeholder="Username"/></br>
          <select id="req-type" style="width:228px;">
            <option value="-1" selected disabled>Request Type</option>
            <option value="song">Song</option>
            <option value="comp">Competition</option>
            <option value="joke">Joke</option>
          </select></br>
          <input id="req-content" placeholder="Message"/>

        </form>
        <button class="btn btn-primary" id="request-button" onclick="request()">Request</button>
      </div>
    </div>
  </div>
</div>
