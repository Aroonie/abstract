$('#volDown').click(function(){
    if(stream.volume > 0){
      stream.volume = stream.volume - 0.1;
    }
  });
  
  $('#volUp').click(function(){
    if(stream.volume < 1){
      stream.volume = stream.volume + 0.1;
    }
  });
  
  $('#toggleRadio').click(function(){
    toggleRadio();
  });
  
  function toggleRadio(){
    if (stream.paused){
      playRadio();
    } else {
      pauseRadio();
    }
  }
  
  function playRadio(){
    stream.src = "http://178.62.29.135:8010/radio.mp3";
    stream.volume = 0;
    $('#toggleRadio').attr("class", "fas fa-circle-notch fa-spin");
    stream.play().then(function() {
      stream.volume = 0.1;
      $('#toggleRadio').attr("class", "fa fa-pause");
    }).catch(function() {
      pauseRadio();
    });
  }
  
  function pauseRadio(){
    stream.pause();
    stream.volume = 0;
    stream.src = "";
    $('#toggleRadio').attr("class", "fa fa-play");
  }