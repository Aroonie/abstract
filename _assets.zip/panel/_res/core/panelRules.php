<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

?>

                <div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-sticky-note">Official Rules Booklet</span>
                    </div>
                    <div class="mws-panel-body">
                    	<div class="mws-panel-content">
<B>Rules for Radio DJ's:</B><br />
Please can all staff members remember we are trying to operate a professional radio and you MUST FOLLOW the following rules while being on the radio. If these rules are NOT followed, this could lead to you receiving warnings and even being removed from the team. Our current set of rules are not strict, and still allow you to have fun. If you feel like you do not understand a rule, contact your Radio Management member. Please read below for our current Radio DJ rules:<br /><br />

<B>- You must play a variety of songs while on the radio, and not stick to the same genre of music, try to mix it!<br />
- You must NOT STREAM on the radio, and you must not swear on the radio, swearing in songs is allowed!<br />
- Radio DJ's must book at least 3 slots per week, if this is not done, you will be removed from the team!<br />
- You must not miss a booked slot, if this happens you will receive a warning, and this will lead to removal!<br />
- Please treat everyone with respect, also if this is not done action will be taken against people being rude!<br />
- The radio timetable clears at 6PM GMT every Sunday, this is UK Times!</B><br /><br />

PLEASE REMEMBER that we want to be like a professional radio station, if you are not up for this, then MadHabbo is not up for keeping you as a member of it's staffing team. Thanks for reading, stick to the rules!<br /><br />
<center>--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</center><br />
<b>General Staff Rules:</B><br />
Please can all staff members remember we are trying to operate a professional events team and you MUST FOLLOW the following rules while being on the events team. If these rules are NOT followed, this could lead to you receiving warnings and even being removed from the team. Our current set of rules are not strict, and still allow you to have fun. If you feel like you do not understand a rule, contact your Events Management member. Please read below for our current Events rules:<br /><br />

<B>- You must not miss a booked event at any time without a reasonable answer to why you did so!<br />
- You must NOT book an event if you have no prizes to issue to the winner(s)<br />
- You must NOT book the same event/game if it was hosted last hour!<br />
- You must NOT swear at users/community in the event while you are hosting/playing!<br />
- You must NOT be rude to Management or disrespectful to anyone else on the team!<br /><br /></B>

PLEASE REMEMBER that we want to be like a professional events department, if you are not up for this, then MadHabbo is not up for keeping you as a member of it's staffing team. Thanks for reading, stick to the rules!

</div>
                    </div>
                </div>