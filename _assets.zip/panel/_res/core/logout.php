<?php
	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }
        $user->destroySession();
?>

<div class="mws-panel grid_8">
    <div class="mws-panel-header">
        <span class="mws-i-24 i-table-1">Logging Out...</span>
    </div>
    <div class="mws-panel-body">
        <div class="mws-form-message error">
            Successfully Logged Out<br />
            Thank you for visiting, <strong><?php echo $user->data['fullUsername']; ?></strong>.
        </div>
        <?php echo $core->redirect( "./", 1 ); ?>
    </div>
</div>