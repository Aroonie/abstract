<?php
	
	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }
	
?>
<?php
$radio = $db->query( "SELECT * FROM connection_info ORDER BY id DESC LIMIT 1" );
$radioarray = $db->assoc( $radio );
$settings = $db->query("SELECT * FROM settings");
$settingarray = $db->assoc($settings);
if ($settingarray['ddos'] == '1') {
echo "";
} else {
$info  = $core->radioInfo( "http://{$radioarray['host']}:{$radioarray['port']}" );
?>

<!-- Statistics Button Container -->
<div class="mws-report-container clearfix">

<a class="mws-report" href="#">
<!-- Statistic Icon (edit to change icon) -->
<span class="mws-report-icon mws-ic ic-heart"></span>

<!-- Statistic Content -->
<span class="mws-report-content">
<span class="mws-report-title">Your Loves</span>
<span class="mws-report-value">
<?php
$totalstaffquery = $db->query("SELECT * FROM users WHERE id = '{$user->data['id']}'");
$totalstaffnumber = $db->assoc($totalstaffquery);
echo $totalstaffnumber['love'];
?>

</span>
</span>
</a>

<a class="mws-report" href="radio.requests">
<!-- Statistic Icon (edit to change icon) -->
<span class="mws-report-icon mws-ic ic-book"></span>

<!-- Statistic Content -->
<span class="mws-report-content">
<span class="mws-report-title">Your Requests</span>
<span class="mws-report-value">
<?php
$totalrequestsquery = $db->query("SELECT * FROM requests WHERE `for` = '{$user->data['id']}'");
$totalrequestsnumber = $db->num($totalrequestsquery);
echo $totalrequestsnumber;
?>
</span>
</span>
</a>

<!-- Statistic Item -->
<a class="mws-report" href="http://sc.madhabbo.com:8880" target="_blank">
<!-- Statistic Icon (edit to change icon) -->
<span class="mws-report-icon mws-ic ic-speakers"></span>

<!-- Statistic Content -->
<span class="mws-report-content">
<span class="mws-report-title">Current Listeners</span>
<span class="mws-report-value">
<?php
if (!$info['online']) {
echo "N/A";
} else {
echo $info['listeners'];
}
?>
</span>
</span>
</a>

<a class="mws-report" href="#">
<!-- Statistic Icon (edit to change icon) -->
<span class="mws-report-icon mws-ic ic-ipod-sound"></span>

<!-- Statistic Content -->
<span class="mws-report-content">
<span class="mws-report-title">Listener Peak</span>
<span class="mws-report-value">
<?php
if (!$info['online']) {
echo "N/A";
} else {
echo $info['listenerpeak'];
}
?>
</span>
</span>
</a>

<a class="mws-report" href="radio.timetable">
<!-- Statistic Icon (edit to change icon) -->
<span class="mws-report-icon mws-ic ic-calendar"></span>

<!-- Statistic Content -->
<span class="mws-report-content">
<span class="mws-report-title">Booked Slots</span>
<span class="mws-report-value">
<?php
$totalbookedquery = $db->query("SELECT * FROM timetable");
$totalbookednumber = $db->num($totalbookedquery);
echo $totalbookednumber;
?>
</span>
</span>
</a>
</div>
<?php
}
?>
<?php
$query = $db->query( "SELECT * FROM announcement" );
$array = $db->assoc($query);
$result = $array['message'];
$result1 = stripslashes($result);
if ($result == '') {
echo "";
} else {
?>

                <div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-alert">Important Notices</span>
                    </div>
                    <div class="mws-panel-body">
                    	<div class="mws-panel-content">
<?php
  echo "<div class=\"result\">" . htmlspecialchars_decode($result1) . "</div>";
?>
                        </div>
                    </div>
                </div>
<?php
}
?>

                <div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-home">Homepage</span>
                    </div>
                    <title> MadHabbo - Staff </title>
                    <div class="mws-panel-body">
                    	<div class="mws-panel-content">
		<B>Welcome to MadHabbo's Staff Portal,</B> this is the heart of the fansite. Without this panel, Radio DJ's would not be able to book their slots, Events Host's would not be able to book their events, and the management and administration would not be able to run the website on a daily basis. We pride ourself in making sure that 
							<strong>MadHabbo</strong> is a professional website, and for this reason we aim to keep it professional. This panel is <B>brand new</B> and therefore it's MadHabbo Staff Portal V1.0. We hope you like the changes!<br /><br />

We've updated this page... and if your looking for the rules then they are located under your department area. To view the rules now, all you have to do is click <B>Home</B> at the left hand side and it will then show a new section entailed <B>Staff Rules</B>. Please make sure these are read and <b>DO NOT</b> carry out your role without reading them. We'd like to thank everyone who's currently working for MadHabbo, we cannot do it without you! Keep up the great work, and make sure you try and gain them promotions, they are all waiting for you... just a finger click away!<br /><br />

As you can tell, we aim to be a professional radio station and events base, so please make sure this is completed on a daily basis. Anyone not active will receive a warning via our new system, and therefore after three/four warnings you will be removed from the department.<br />
<B>MadHabbo Ownership</B>
                        </div>
                    </div>
                </div>