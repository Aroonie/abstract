<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

?>
            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-home">Change Your Habbo Name</span>
                    </div>
                    <div class="mws-panel-body">
                    	<form action="" method="post" id="changeHabbo" class="mws-form">
		<?php

			if( $_POST['submit'] ) {

				try {

					$habbo = $core->clean( $_POST['habbo'] );

					if( !$habbo ) {

						throw new Exception( "All fields are required." );

					}
					else {

						$db->query( "UPDATE users SET habbo = '{$habbo}' WHERE id = '{$user->data['id']}'" );

						echo "<div class=\"mws-form-message success\">Success!<ul><li>Habbo name successfully changed!</li></ul></div>";

					}

				}
				catch( Exception $e ) {
	
					echo "<div class=\"mws-form-message error\">";
					echo "Error";
					echo "<br /><strong>";
					echo "Invalid Habbo Name";
					echo "</strong></div>";

				}

			}

		?>
                    		<div class="mws-form-inline">
                    			<div class="mws-form-row">
                    				<label>Change Habbo</label>
                    				<div class="mws-form-item medium">
                    						<input type="text" class="mws-textinput" id="habbo" name="habbo" />
                    				</div>
                    			</div>
                    		</div>
                    		<div class="mws-button-row">
                    			<input type="submit" name="submit" value="Submit" class="mws-button red" />
                    			<input type="reset" value="Reset" class="mws-button gray" />
                    		</div>
                    	</form>
                    </div>    	
                </div>

<?php
	echo $core->buildFormJS('changeHabbo');
?>