<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

?>

<style type="text/css">
	a {
		text-decoration: none;
	}
</style>

<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-alert">Notice</span>
                    </div>
                    <div class="mws-panel-body">
                    	<div class="mws-panel-content">
The Change Password feature may look confusing, please note that this is the way that you will have to change your password:<br />
<strong>Top Box:</strong> Current Password<br />
<strong>Bottom Box:</strong> New Password<br />
<br />
If you need any help with changing your password, please contact your Manager!, if you find an error on this page, please contact <strong><a href="skype:unkn-0wn">Mark</a></strong> with the code: <strong>ChngPW01Bug</strong> and state what issue you're having!
</div>
                    </div>
                </div>






                <div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-sticky-note">Change Password</span>
                    </div>
                    <div class="mws-panel-body">
                    	<div class="mws-panel-content">
<form action="" method="post" id="changePassword">

	<div class="box">

		<?php
		
			if( $_POST['submit'] ) {
	
				try {
	
					$oldpassword     = $core->clean( $_POST['current_password'] );
					$oldpassword_enc = $core->encrypt( $oldpassword );
	
					$newpassword     = $core->clean( $_POST['new_password'] );
					$newpassword_enc = $core->encrypt( $newpassword );
	
					if( !$oldpassword or  !$newpassword) {
	
						throw new Exception( "All fields are required." );
	
					}
					elseif( $oldpassword_enc != $user->data['password'] ) {
	
						throw new Exception( "The password you entered does not match the one we have on record." );
	
					}
					else {
	
						$db->query( "UPDATE users SET password = '{$newpassword_enc}' WHERE id = '{$user->data['id']}'" );
						
						echo "<div class=\"square good\">";
						echo "<strong>Success</strong>";
						echo "<br />";
						echo "Password successfully changed!";
						echo "</div>";
	
					}
	
				}
				catch( Exception $e ) {
	
					echo "<div class=\"square bad\">";
					echo "<strong>Error</strong>";
					echo "<br />";
					echo $e->getMessage();
					echo "</div>";
	
				}
	
			}
		
		?>

		<table width="100%" cellpadding="3" cellspacing="0">

			<?php
				echo $core->buildField( "password",
										"required",
										"current_password",
										"Current password",
										"Your current password" );


				echo $core->buildField( "password",
										"required",
										"new_password",
										"New password",
										"Your desired new password." );
			?>
		</table>
	
	<div align="right">
	
		<input class="btn btn-primary" type="submit" name="submit" value="Submit" />
	
	</div>

</form>

<?php
	echo $core->buildFormJS('changePassword');
?>

<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

?>




</div>
                    </div>
                </div>