<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

?>

            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-table-1">Manage Users</span>
                    </div>
                    <div class="mws-panel-body">
                        <table class="mws-table">
                            <thead>
                                <tr>
                                    <th>Username</th>
                                    <th>Habbo Name</th>
                                    <th>DJ Name</th>
                                    <th>Role</th>
                                    <th width="60">Controls</th>
                                </tr>
                            </thead>
                            <tbody>
	<?php
                $query = $db->query( "SELECT * FROM users ORDER BY username ASC" );
		$num   = $db->num( $query );

		$j = "a";

		if( $user->hasGroup( '5' ) ) {
			while( $array = $db->assoc( $query ) ) {

				echo "<tr class=\"row {$j}\" id=\"user_{$array['id']}\">";

				echo "<td>";
				echo $array['username'];
				if( $array['deleteid'] == '1' ){
				echo " <i>(This person is pending removal!)</i>";
				}else{}
				echo "</td>";
				echo "<td>";
				echo $array['habbo'];
				echo "</td>";
				echo "<td>";
				echo $array['djname'];
				echo "</td>";
				echo "<td>";
				echo $array['role'];
				echo "</td>";
				echo "<td><center>";
                                if( $array['id'] == $user->data['id'] AND $array['deleteid'] == '2' ){
				echo "<a href=\"mgmt.addUser?id={$array['id']}\">";
				echo "<img src=\"_img/pencil.png\" alt=\"Edit\" />";
				echo "</a>";}
				elseif( $array['deleteid'] == '2' AND $array['id'] != $user->data['id'] ){ }
				elseif( $array['deleteid'] == '1' ){
				echo "";
				}else{
				echo "<a href=\"mgmt.addUser?id={$array['id']}\">";
				echo "<img src=\"_img/pencil.png\" alt=\"Edit\" />";
				echo "</a>";
				echo "<a href=\"#\" onclick=\"Radi.deleteUser2('{$array['id']}');\">";
				echo "<img src=\"_img/minus.png\" alt=\"Delete\" />";
				echo "</a>";
				}
				echo "</center></td>";

				echo "</tr>";

				$j++;

				if( $j == "c" ) {

					$j = "a";

				}

			}
		}
		else
		{
			while( $array = $db->assoc( $query ) ) {
				$test->data['uGroupArray'] = explode( ",", $array['usergroups'] );

				if(!in_array('5', $test->data['uGroupArray']) && !in_array('4', $test->data['uGroupArray'])){
					
				echo "<tr class=\"row {$j}\" id=\"user_{$array['id']}\">";

				echo "<td>";
				echo $array['username'];
				if( $array['deleteid'] == '1' ){
				echo " <i>(Pending Removal)</i>";
				}else{}
				echo "</td>";
				echo "<td>";
				echo $array['habbo'];
				echo "</td>";
				echo "<td>";
				echo $array['role'];
				echo "</td>";
				echo "<td><center>";

                                if( $array['id'] == $user->data['id'] AND $array['deleteid'] == '2' ){
				echo "<a href=\"mgmt.addUser?id={$array['id']}\">";
				echo "<img src=\"_img/pencil.png\" alt=\"Edit\" />";
				echo "</a>";}
				elseif( $array['deleteid'] == '2' AND $array['id'] != $user->data['id'] ){ }
				elseif( $array['deleteid'] == '1' ){
				echo "";
				}else{
				echo "<a href=\"mgmt.addUser?id={$array['id']}\">";
				echo "<img src=\"_img/pencil.png\" alt=\"Edit\" />";
				echo "</a>";
				echo "<a href=\"#\" onclick=\"Radi.deleteUser2('{$array['id']}');\">";
				echo "<img src=\"_img/minus.png\" alt=\"Delete\" />";
				echo "</a>";
				}
				echo "</center></td>";

				echo "</tr>";

				$j++;

				if( $j == "c" ) {

					$j = "a";

				}
				}

			}
		}

	?>
                            </tbody>
                        </table>
                    </div>
                </div>