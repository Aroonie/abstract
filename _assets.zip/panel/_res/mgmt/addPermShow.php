<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

	if( $_GET['id'] ) {

		$id = $core->clean( $_GET['id'] );

		$query = $db->query( "SELECT * FROM timetable WHERE id = '{$id}'" );
		$data  = $db->assoc( $query );

		$editid = $data['id'];

	}

?>
            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-home">Add Permanent Show</span>
                    </div>
                    <div class="mws-panel-body">
                    	<form action="" method="post" id="addPermShow" class="mws-form">
                    		<div class="mws-form-inline">
		<?php

			if( $_POST['submit'] ) {

				try {

					$day  = $core->clean( $_POST['day'] );
					$time = $core->clean( $_POST['time'] );
					$dj   = $core->clean( $_POST['dj'] ); 

					if( !$day or !$time or !$dj ) {

						throw new Exception( "All fields are required." );

					}
					else {

						if( $editid ) {

							$db->query( "UPDATE timetable SET day = '{$day}', time = '{$time}', dj = '{$dj}' WHERE id = '{$editid}'" );

						}
						else {

							$db->query( "INSERT INTO timetable VALUES (NULL, '{$day}', '{$time}', '{$dj}', '1');" );
$date  = date("l jS \of F Y h:i:s A");
        $ipAddress = $_SERVER['REMOTE_ADDR'];
$db->query( "INSERT INTO logs VALUES (NULL, '{$user->data['username']}', '{$ipAddress}', '{$date}', 'Added Permanent Show')" );

						}

						echo "<div class=\"mws-form-message success\">Success!<ul><li>Permanent show added!</li></ul></div>";

					}

				}
				catch( Exception $e ) {

					echo "<div class=\"mws-form-message error\">";
					echo "Error";
					echo "<ul><li>";
					echo $e->getMessage();
					echo "</li></ul></div>";

				}

			}

		?>

			<?php

				for( $j = 0; $j <= 23; $j++ ) {

					if( $j < 10 ) {

						$time = "0{$j}:00";

					}
					else {

						$time = "{$j}:00";

					}

					$times[] = $time;

				}
				
				foreach( $times as $key => $value ) {
					
					if( $key == $data['time'] ) {
						
						$times[$key . '_active'] = $value;
						
						unset( $times[$key] );
						
					}
					
				}

				$days = array( 1 => "Monday",
							   2 => "Tuesday",
							   3 => "Wednesday",
							   4 => "Thursday",
							   5 => "Friday",
							   6 => "Saturday",
							   7 => "Sunday" );

				foreach( $days as $key => $value ) {

					if( $key == $data['day'] ) {

						$days[$key . '_active'] = $value;

						unset( $days[$key] );

					}

				}

				$query = $db->query( "SELECT * FROM users" );
				
				while( $array = $db->assoc( $query ) ) {
					
					$djs[$array['id']] = $array['username'];
					
				}

				foreach( $djs as $key => $value ) {

					if( $key == $data['dj'] ) {

						$djs[$key . '_active'] = $value;

						unset( $djs[$key] );

					}

				}


				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Slot Day</label>";
				echo "<div class=\"mws-form-item clearfix\">";
				echo $core->buildField( "select",
										"required",
										"day",
										"",
										"",
										$days );
				echo "</div></div>";

				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Slot Time</label>";
				echo "<div class=\"mws-form-item clearfix\">";
				echo $core->buildField( "select",
										"required",
										"time",
										"",
										"",
										$times );
				echo "</div></div>";

				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Radio DJ</label>";
				echo "<div class=\"mws-form-item clearfix\">";
				echo $core->buildField( "select",
										"required",
										"dj",
										"",
										"",
										$djs );
				echo "</div></div>";

			?>
                    		</div>
                    		<div class="mws-button-row">
                    			<input type="submit" name="submit" value="Submit" class="mws-button red" />
                    			<input type="reset" value="Reset" class="mws-button gray" />
                    		</div>
                    	</form>
                    </div>    	
                </div>

<?php
	
	echo $core->buildFormJS('addPermShow');

?>