<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

        $date  = date("l jS \of F Y h:i:s A");
        $ipAddress = $_SERVER['REMOTE_ADDR'];
                if (array_key_exists('HTTP_X_FORWARDED_FOR', $_SERVER)) {
                    $ipAddress = array_pop(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']));
        }

	if( $_GET['id'] ) {

		$id = $core->clean( $_GET['id'] );

		$query = $db->query( "SELECT * FROM users WHERE id = '{$id}'" );
		$data  = $db->assoc( $query );
		
		$data['ugroups'] = explode( ",", $data['usergroups'] );

		$editid = $data['id'];

	}

function randomPassword() {
    $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 13; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass);
}

?>
                <div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-alert">Management Notice</span>
                    </div>
                    <div class="mws-panel-body">
                    	<div class="mws-panel-content">
                    		When adding a user to the panel, the box to the right of the password field, you need to copy and paste that to the user, as well as paste that password into the box to the left of it to set the password.
                        </div>
                    </div>
                </div>


            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-home">Add User</span>
                    </div>
                    <div class="mws-panel-body">
                    	<form action="" method="post" id="addUser" class="mws-form">
                    		<div class="mws-form-inline">

		<?php

			if( $_POST['submit'] ) {

				try {

					$username = $core->clean( $_POST['username'] );
					$password = $core->clean( $_POST['password'] );
					$habbo    = $core->clean( $_POST['habbo'] );
					$role    = $core->clean( $_POST['role'] );
					$djname    = $core->clean( $_POST['djname'] );
					$dgroup   = $core->clean( $_POST['dgroup'] );
					$query    = $db->query( "SELECT * FROM usergroups" );
					while( $array = $db->assoc( $query ) ) {
						if( $_POST['ugroup-' . $array['id']] ) {
							$ugroups .= $array['id'] . ",";
					}
					}
					$password_enc = $core->encrypt( $password );
					if( !$username or ( !$password and !$editid ) or !$dgroup or !$ugroups ) {
						throw new Exception( "All fields are required." );
					}
					else {
						if( $editid ) {
							if( $password ) {
								$password = ", password = '{$password_enc}'";
							}
							else {
								unset( $password );
							}
							$db->query( "UPDATE users SET username = '{$username}' {$password}, habbo = '{$habbo}', role = '{$role}', displaygroup = '{$dgroup}', usergroups = '{$ugroups}',  djname = '{$djname}' WHERE id = '{$editid}'" );
							$db->query( "INSERT INTO logs VALUES (NULL, '{$user->data['username']}', '{$ipAddress}', '{$date}', 'Edited {$username}s panel account')" );

						}
						else {
						$joindate = time();
							$db->query( "INSERT INTO users VALUES (NULL, '{$username}', '{$password_enc}', '{$habbo}', '{$role}', '{$dgroup}', '{$ugroups}', '0', '', '0', '0', '0', '{$joindate}', '{$djname}');" );
							$db->query( "INSERT INTO logs VALUES (NULL, '{$user->data['username']}', '{$ipAddress}', '{$date}', 'Added {$username} to the panel')" );
						
						}

						echo "<div class=\"mws-form-message success\">Success!<ul><li>User successfully added/edited!</li></ul></div>";

					}

				}
				catch( Exception $e ) {
	
					echo "<div class=\"mws-form-message error\">";
					echo "Error";
					echo "<ul><li>";
					echo $e->getMessage();
					echo "</li></ul></div>";

				}

			}

		?>

            <?php

                // Here, we check if the user is part of management, but not an administrator!
                if( $user->hasGroup( '4' ) AND !$user->hasGroup( '5' ) ) {
                    // The user is a member of the management group, and as such, we get all usergroups apart from administrator
                    $query = $db->query( "SELECT * FROM usergroups WHERE id != '5' AND id != '6' AND id != '4' AND id !='3'" );
                } elseif( $user->hasGroup( '5' ) AND !$user->hasGroup( '6' ) ) {
                    $query = $db->query( "SELECT * FROM usergroups WHERE id != '6'" );
                } else {
                    $query = $db->query( "SELECT * FROM usergroups" );
                
                }
                
                while( $array = $db->assoc( $query ) ) {
                    
                    if( in_array( $array['id'], $data['ugroups'] ) ) {
                        
                        $groups[$array['id'] . '_active'] = $array['name'];
                    
                    }
                    else {
                    
                        $groups[$array['id']] = $array['name'];
                    
                    }
                    
                    if( $array['id'] == $data['displaygroup'] ) {
                    
                        $dgroups[$array['id'] . '_active']  = $array['name'];
                    
                    }
                    else {
                    
                        $dgroups[$array['id']]  = $array['name'];
                    
                    }
                    
                }



				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Username</label>";
				echo "<div class=\"mws-form-item clearfix\">";
				echo $core->buildField( "text",
										"required",
										"username",
										"",
										"The new username.",
										$data['username'] );
				echo "</div></div>";

				echo "<div class=\"mws-form-row\" style=\"margin: -30px 0 0 643px;\">";
				echo "<div class=\"mws-form-item clearfix\">";
                    		echo "<label>Password Generator:</label>";
				echo "</div></div>";

				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Password</label>";
				echo "<div class=\"mws-form-item clearfix\">";
				echo "<input type=\"text\" id=\"password\" name=\"password\" class=\"mws-textinput\" style=\"width: 634px;\" />";
				echo "</div></div>";

				echo "<div class=\"mws-form-row\" style=\"margin: -58px 0 0 643px;\">";
				echo "<div class=\"mws-form-item clearfix\">";
				echo "<input type=\"text\" class=\"mws-textinput\" value=\"";
				echo randomPassword();
				echo "\" style=\"width: 150px;\" readonly=\"readonly\" />";
				echo "</div></div>";

				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Habbo Name</label>";
				echo "<div class=\"mws-form-item clearfix\">";
				echo $core->buildField( "text",
										"",
										"habbo",
										"",
										"The new Habbo name (optional).",
										$data['habbo'] );
				echo "</div></div>";
				
				echo "<div class=\"mws-form-row\">";
                echo "<label>DJ Name (if applicable)</label>";
				echo "<div class=\"mws-form-item clearfix\">";
				echo $core->buildField( "text",
										"",
										"djname",
										"",
										"The DJs name (optional).",
										$data['djname'] );
				echo "</div></div>";

				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Role</label>";
				echo "<div class=\"mws-form-item clearfix\">";
				echo $core->buildField( "text",
										"required",
										"role",
										"",
										"The new Role of the user.",
										$data['role'] );
				echo "</div></div>";

				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Display Group</label>";
				echo "<div class=\"mws-form-item clearfix\">";
                    		echo $core->buildField( "select",
										"required",
										"dgroup",
										"",
										"",
										$dgroups );
				echo "</div></div>";

				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Active Usergroups</label>";
				echo "<div class=\"mws-form-item clearfix\">";
				echo "<ul class=\"mws-form-list\">";
				echo $core->buildField( "checkbox",
										"required",
										"ugroup",
										"",
										"The user's active groups.",
										$groups );
				echo "</ul>";
				echo "</div></div>";

			?>

                    		</div>
                    		<div class="mws-button-row">
                    			<input type="submit" name="submit" value="Submit" class="mws-button red" />
                    			<input type="reset" value="Reset" class="mws-button gray" />
                    		</div>
                    	</form>
                    </div>    	
                </div>
<?php
	echo $core->buildFormJS('addUser');

?>