 <div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-home">Management Tasks</span>
                    </div>
                    <div class="mws-panel-body">
                    	<div class="mws-panel-content">
As a department Manager, we have high expectations of you. We feel as if management is one of the more important roles when running a fansite, and we need our managers to be 100% dedicated and committed, otherwise this site would not work. You are in this position for a reason – we feel as if you’re good enough to complete these tasks:
<br><br>
• Radio: You are required to complete at least 3 radio slots per week. We want to see you setting an example to the Head DJs and Radio DJs and push them to get on air. This is a perfect way to motivate them! It gives them a goal and something to push for.<br>
• Events: We expect to see you completing 3 events per week. This is for the exact reason as listed above.<br>
• It’d be great if you could hire 1 staff member each for your department per week. We want to expand our team and make sure all of our departments are strong, so please try to get as much staff as possible.<br>
• You are expected to set weekly objectives for t to reach. This can be done in a points system, and maybe the person with the highest amount of points can get a prize from you? It’s your department – come up with ideas!<br>
• You are required to issues warnings as and when needed. This is KEY as we need staff that are willing to obey the rules at all times.<br>
• Radio: Hold regular meetings with the Head DJs so they know how well they’re doing, or whether they need to improve. These should be verbal meetings over a Skype call at a convenient time for all General Management staff for that timezone.<br>
• Write a weekly written review for the Head DJ team. This should be in depth and include their strengths, weaknesses and improvements for the next week.<br>
• Be a mature role model when it comes to situations like arguments in the chat. For example, if there were a conflict between a Head DJ and another member of staff <i>(below in rank)</i>, it would be your duty to get them both into a conversation and sort it out. <br>
• Radio Managers: Organize who clears the timetable each week. This must change every week.
 </div>
                    </div>
                </div>