<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

?>
            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-table-1">DJ Reviews</span>
                    </div>
                    <div class="mws-panel-body">
                        <table class="mws-table">
                            <thead>
                                <tr>
                                    <th>Habbo Name</th>
                                    <th>Review</th>
                                    <th>DJ</th>
                                    <th width="60">Controls</th>
                                </tr>
                            </thead>
                            <tbody>
	<?php

                $query = $db->query( "SELECT * FROM djreviews ORDER BY id DESC" );
		$num   = $db->num( $query );

		$j = "a";

		while( $array = $db->assoc( $query ) ) {
$query2 = $db->query("SELECT * FROM users WHERE id = '{$array['dj']}'");
$array2 = $db->assoc($query2);

			echo "<tr class=\"row {$j}\" id=\"review_{$array['id']}\">";

			echo "<td>" . $array['habbo'] . "</td>";
			echo "<td>" . $array['review'] . "</td>";
			echo "<td>" . $array2['username'] . "</td>";
                        echo "<td>";
			echo "<center><a href=\"#\" onclick=\"Radi.deleteReviews('{$array['id']}');\">";
			echo "<img src=\"_img/minus.png\" alt=\"Delete\" />";
			echo "</a></center>";
			echo "</td>";


			$j++;

			if( $j == "c" ) {

				$j = "a";

			}

		}

		if( $num == 0 ) {

			echo "<div class=\"mws-form-message error\">";
			echo "Sorry";
			echo "<ul><li>";
			echo "There are no dj reviews.";
			echo "</li></ul></div>";

		}

	?>
                            </tbody>
                        </table>
                    </div>
                </div>