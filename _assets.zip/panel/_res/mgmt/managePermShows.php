<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

?>
            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-table-1">Manage Permanent Shows</span>
                    </div>
                    <div class="mws-panel-body">
                        <table class="mws-table">
                            <thead>
                                <tr>
                                    <th>Radio DJ</th>
                                    <th>Slot Day</th>
                                    <th>Slot Time</th>
                                    <th width="80">Controls</th>
                                </tr>
                            </thead>
                            <tbody>
	<?php

		$query = $db->query( "SELECT * FROM timetable WHERE perm = '1'" );
		$num   = $db->num( $query );

		$j = "a";

		while( $array = $db->assoc( $query ) ) {

			if( $array['time'] < 10 ) {

				$time = "0{$array['time']}:00";

			}
			else {

				$time = "{$array['time']}:00";

			}

			$day = strtotime( "{$array['day']} november 2010" );
			$day = date( "l", $day );

			$query2 = $db->query( "SELECT * FROM users WHERE id = '{$array['dj']}'" );
			$array2 = $db->assoc( $query2 );

			echo "<tr class=\"row {$j}\" id=\"permshow_{$array['id']}\">";


			echo "<td>{$array2['username']}</td>";
			echo "<td>{$day}</td>";
			echo "<td>{$time}</td>";

			echo "<td><center>";
			echo "<a href=\"#\" onclick=\"Radi.deletePermShow('{$array['id']}');\">";
			echo "<img src=\"_img/minus.png\" alt=\"Delete\" />";
			echo "</a>";

			echo "<a href=\"mgmt.addPermShow?id={$array['id']}\">";
			echo "<img src=\"_img/pencil.png\" alt=\"Edit\" />";
			echo "</a>";
			echo "</center></td>";

			echo "</tr>";

			$j++;

			if( $j == "c" ) {

				$j = "a";

			}

		}

		if( $num == 0 ) {

			echo "<div class=\"mws-form-message error\">";
			echo "Sorry";
			echo "<ul><li>";
			echo "There are no permanent shows to manage.";
			echo "</li></ul></div>";

		}

	?>
                            </tbody>
                        </table>
                    </div>
                </div>