<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

	$current = $db->query( "SELECT * FROM announcement" );
	while( $array = $db->assoc( $current ) ) {
		$result = stripslashes($array['message']);
	}

?>
            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-home">Add Notice</span>
                    </div>
                    <div class="mws-panel-body">
                    	<form action="" method="post" id="addAnnouncement" class="mws-form">
                    		<div class="mws-form-inline">
		<?php

			if( $_POST['submit'] ) {

				try {

					$message = $core->clean( $_POST['message'] );

					if( !$message ) {

						throw new Exception( "All fields are required." );

					}
					else {

						$db->query( "UPDATE announcement SET message = '{$message}'" );
						$db->query( "INSERT INTO logs VALUES (NULL, '{$user->data['username']}', '{$ipAddress}', '{$date}', 'Updated Panel Announcements')" );

						echo "<div class=\"mws-form-message success\">Success!<ul><li>Your Announcement has been successfully Updated!</li></ul></div>";

					}

				}
				catch( Exception $e ) {

					echo "<div class=\"mws-form-message error\">";
					echo "Error";
					echo "<ul><li>";
					echo $e->getMessage();
					echo "</li></ul></div>";

				}

			}

		?>
			<?php

				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Announcements</label>";
				echo "<div class=\"mws-form-item clearfix\">";
				echo $core->buildField( "verybig_textarea",
										"required",
										"message",
										"",
										"",
										$result );
				echo "</div></div>";

			?>
                    		</div>
                    		<div class="mws-button-row">
                    			<input type="submit" name="submit" value="Submit" class="mws-button red" />
                    			<input type="reset" value="Reset" class="mws-button gray" />
                    		</div>
                    	</form>
                    </div>    	
                </div>

<?php
	echo $core->buildFormJS('addAnnouncement');
?>