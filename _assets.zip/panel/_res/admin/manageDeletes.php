<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }
?>

            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-table-1">Manage Account Delete Requests</span>
                    </div>
                    <div class="mws-panel-body">
<?php

	if( $_GET['approve'] ) {
		$approve = $core->clean( $_GET['approve'] );
		$db->query( "UPDATE users SET deleteid = '0', deleteuser = '' WHERE id = '{$approve}'" );

		echo "<div class=\"mws-form-message success\">";
		echo "Success!<br />";
		echo "User has been granted permissions back.";
		echo "</div>";

		echo $core->redirect( "admin.manageDeletes", 1 );
	}
?>
                        <table class="mws-table">
                            <thead>
                                <tr>
                                    <th>Account to be deleted</th>
                                    <th>User who requested delete</th>
                                    <th width="60">Controls</th>
                                </tr>
                            </thead>
                            <tbody>
	<?php
		$query = $db->query( "SELECT * FROM users WHERE deleteid = '1' ORDER BY id" );
		$num   = $db->num( $query );
		$j = "a";

		while( $array = $db->assoc( $query ) ) {
			$query1 = $db->query( "SELECT * FROM users WHERE id = '{$array['id']}'" );
			$array1 = $db->assoc( $query1 );

			echo "<tr class=\"wTitle {$j}\" id=\"user_{$array['id']}\">";

			echo "<td>" . $array1['username'] . "</td>";
			echo "<td>" . $array['deleteuser'] . "</td>";

			echo "<td><center>";
			echo "<a href=\"#\" onclick=\"Radi.deleteUser('{$array['id']}');\">";
			echo "<img src=\"_img/tick.png\" alt=\"Approve\" title=\"Approve Deletion\" />";
			echo "</a>";

			echo "<a href=\"?approve={$array['id']}\">";
			echo "<img src=\"_img/minus.png\" alt=\"Deny\" title=\"Deny Deletion\" />";
			echo "</a>";
			echo "</center></td>";

			echo "</tr>";

			$j++;
			if( $j == "c" ) {
				$j = "a";
			}
		}

		if( $num == 0 ) {
			echo "<div class=\"mws-form-message error\">";
			echo "Whoops...<br />";
			echo "It appears there is nobody to remove from MadHabbo, try again later!";
			echo "</div>";
		}

	?>
                            </tbody>
                        </table>
                    </div>
                </div>