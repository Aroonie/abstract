<?php
	
	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }
	
?>
            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-cog">Update DDOS Mode</span>
                    </div>
                    <div class="mws-panel-body">
                    	<form action="" method="post" id="changeHabbo" class="mws-form">
		<?php

        if (isset($_POST['submit'])) {
$check = $db->query("SELECT * FROM settings");
$checkarray = $db->assoc($check);
if ($checkarray['ddos'] == '1') {
           echo "<div class=\"mws-form-message success\">Success!<ul><li>DDOS Mode Disabled</li></ul></div>";
           $db->query("UPDATE settings SET ddos = '0'");
} else {
           echo "<div class=\"mws-form-message success\">Success!<ul><li>DDOS Mode Enabled</li></ul></div>";
           $db->query("UPDATE settings SET ddos = '1'");
}

        }

		?>
                    		<div class="mws-form-inline">
                    			<div class="mws-form-row">
                    				This tool is to be used when MadHabbo is loading slowly or the radio server is down. All actions on this page are logged.
                    			</div>
                    		</div>
                    		<div class="mws-button-row">
<?php
$check = $db->query("SELECT * FROM settings");
$checkarray = $db->assoc($check);
if ($checkarray['ddos'] == '1') {
?>
                    			<input type="submit" name="submit" value="Disable DDOS Mode" class="mws-button red" />
<?php
} else {
?>
                    			<input type="submit" name="submit" value="Enable DDOS Mode" class="mws-button red" />
<?php
}
?>
                    		</div>
                    	</form>
                    </div>    	
                </div>