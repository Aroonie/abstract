<?php
// Prevent the script from being called directly
if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }
?>
<form action="" method="post" id="addUpdate">

	<div class="box">

		<div class="square title">
			<strong>Post Update</strong>
		</div>

		<?php
		// Check if the form has been submitted
			if( $_POST['submit'] ) {

				try {
					$type       = $core->clean( $_POST['type'] );
					$message    = $core->clean( $_POST['message'] );
					$date       = time();

					$querycheck = $db->query( "SELECT * FROM updates_types WHERE id = '{$type}' AND permissions = 'developer'" );
					$datacheck  = $db->assoc( $querycheck );

					if( !$type or !$message ) {

						throw new Exception( "All fields are required." );

					}
					else if( !$datacheck['name'] ) {

						throw new Exception( "We were unable to find this update type, please try again." );

					}
					else {


						$db->query( "INSERT INTO updates VALUES (NULL, '{$user->data['id']}', '{$_SERVER['REMOTE_ADDR']}', '{$type}', '{$message}', '{$date}');" );


						echo "<div class=\"square good\">";
						echo "<strong>Success</strong>";
						echo "<br />";
						echo "Update posted!";
						echo "</div>";

					}

				}
				catch( Exception $e ) {

					echo "<div class=\"square bad\">";
					echo "<strong>Error</strong>";
					echo "<br />";
					echo $e->getMessage();
					echo "</div>";

				}

			}
?>
		<p>Want to let everyone know what's going on? Use this tool to do so!</p>
		<table width="100%" cellpadding="3" cellspacing="0">

		<?php

		$getTypes = $db->query( "SELECT * FROM updates_types WHERE permissions = 'developer'" );
		while( $array55 = $db->assoc( $getTypes ) ) {
                    $types[$array55['id']]  = $array55['name'];
		}

                echo $core->buildField( "select",
                                        "required",
                                        "type",
                                        "Type",
                                        "Type of update.",
                                        $types );

		echo $core->buildField( "text",
										"required",
										"message",
										"Message",
										"The message in the update.");
                                        
		?>

		</table>

		<div class="box" align="right">
			<input class="button" type="submit" name="submit" value="Submit" />
		</div>
	</div>
</form>
<?php
echo $core->buildFormJS('addUpdate');
?>