<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

	if( $_GET['id'] ) {

		$id = $core->clean( $_GET['id'] );

		$query = $db->query( "SELECT * FROM menu WHERE id = '{$id}'" );
		$data  = $db->assoc( $query );

		if( $data['protected'] == "1" ) {
			
			echo "Protected";
			die();
			
		}

		$editid = $data['id'];

	}

?>
            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-home">Add Menu Item</span>
                    </div>
                    <div class="mws-panel-body">
                    	<form action="" method="post" id="addMenuItem" class="mws-form">
                    		<div class="mws-form-inline">
		<?php

			if( $_POST['submit'] ) {

				try {

					$text     = $core->clean( $_POST['text'] );
					$url      = $core->clean( $_POST['url'] );
					$resource = $core->clean( $_POST['resource'] );
					$ugroup   = $core->clean( $_POST['ugroup'] );

					if( !$text or !$url or !$resource or !$ugroup ) {

						throw new Exception( "All fields are required." );

					}
					else {

						if( $editid ) {

							$db->query( "UPDATE menu SET text = '{$text}', url = '{$url}', resource = '{$resource}', usergroup = '{$ugroup}' WHERE id = '{$editid}'" );

						}
						else {

							$query = $db->query( "SELECT * FROM menu WHERE usergroup = '{$ugroup}' ORDER BY weight DESC LIMIT 1" );
							$array = $db->assoc( $query );

							$weight = $array['weight'] + 1;

							$db->query( "INSERT INTO menu VALUES (NULL, '{$text}', '{$url}', '{$resource}', '{$ugroup}', '0', '{$weight}', '0');" );

						}

						echo "<div class=\"mws-form-message success\">Success!<ul><li>Menu item successfully added!</li></ul></div>";

					}

				}
				catch( Exception $e ) {

					echo "<div class=\"mws-form-message error\">";
					echo "Error";
					echo "<ul><li>";
					echo $e->getMessage();
					echo "</li></ul></div>";

				}

			}

		?>

			<?php

				$query = $db->query( "SELECT * FROM usergroups" );

				while( $array = $db->assoc( $query ) ) {

					if( $array['id'] == $data['usergroup'] ) {

						$ugroups[$array['id'] . '_active'] = $array['name'];

					}
					else {

						$ugroups[$array['id']] = $array['name'];

					}
				
				}
									
				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Text</label>";
				echo "<div class=\"mws-form-item clearfix\">";	
				echo $core->buildField( "text",
										"required",
										"text",
										"",
										"",
										$data['text'] );
				echo "</div></div>";
									
				echo "<div class=\"mws-form-row\">";
                    		echo "<label>URL</label>";
				echo "<div class=\"mws-form-item clearfix\">";	
				echo $core->buildField( "text",
										"required",
										"url",
										"",
										"",
										$data['url'] );
				echo "</div></div>";
									
				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Resource</label>";
				echo "<div class=\"mws-form-item clearfix\">";	
				echo $core->buildField( "text",
										"required",
										"resource",
										"",
										"",
										$data['resource'] ? $data['resource'] : '_res/' );
				echo "</div></div>";
									
				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Usergroup</label>";
				echo "<div class=\"mws-form-item clearfix\">";	
				echo $core->buildField( "select",
										"required",
										"ugroup",
										"",
										"",
										$ugroups );
				echo "</div></div>";

			?>

                    		</div>
                    		<div class="mws-button-row">
                    			<input type="submit" name="submit" value="Submit" class="mws-button red" />
                    			<input type="reset" value="Reset" class="mws-button gray" />
                    		</div>
                    	</form>
                    </div>    	
                </div>

<?php
	echo $core->buildFormJS('addMenuItem');

?>