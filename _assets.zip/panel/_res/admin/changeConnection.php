<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

        $date  = date("l jS \of F Y h:i:s A");
        $ipAddress = $_SERVER['REMOTE_ADDR'];
                if (array_key_exists('HTTP_X_FORWARDED_FOR', $_SERVER)) {
                    $ipAddress = array_pop(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']));
        }

?>
            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-home">Change Connection Information</span>
                    </div>
                    <div class="mws-panel-body">
                    	<form action="" method="post" id="addConnection" class="mws-form">
                    		<div class="mws-form-inline">
		<?php

			if( $_POST['submit'] ) {

				try {

					$host     = $core->clean( $_POST['host'] );
					$port     = $core->clean( $_POST['port'] );
					$password = $core->clean( $_POST['password'] );

					if( !$host or !$port or !$password ) {

						throw new Exception( "All fields are required." );

					}
					else {

						$ip = $_SERVER['REMOTE_ADDR'];

						$db->query( "INSERT INTO connection_info VALUES (NULL, '{$host}', '{$port}', '{$password}', '{$user->data['id']}', '{$ip}'); " );
						$db->query( "INSERT INTO logs VALUES (NULL, '{$user->data['username']}', '{$ipAddress}', '{$date}', 'Changed Connection Information')" );

					echo "<div class=\"mws-form-message success\" align=\"left\">";
					echo "<strong>Success</strong>";
					echo "<br />";
					echo "The radio information was successfully changed!";
					echo "</div>";

					}

				}
				catch( Exception $e ) {

					echo "<div class=\"mws-form-message error\" align=\"left\">";
					echo "<strong>Whoops...</strong>";
					echo "<br />";
					echo "Either there is an error in our system or You have done something wrong... Contact Mark with the code (RadiDets01).";
					echo "</div>"; 

				}

			}

		?>

			<?php

				echo "<div class=\"mws-form-row\">";
                    		echo "<label>IP Address</label>";
				echo "<div class=\"mws-form-item clearfix\">";
				echo $core->buildField( "text",
										"required",
										"host",
										"",
										"" );
				echo "</div></div>";

				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Port</label>";
				echo "<div class=\"mws-form-item clearfix\">";
				echo $core->buildField( "text",
										"required",
										"port",
										"",
										"" );
				echo "</div></div>";

				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Password</label>";
				echo "<div class=\"mws-form-item clearfix\">";
				echo $core->buildField( "password",
										"required",
										"password",
										"",
										"" );
				echo "</div></div>";


			?>
                    		</div>
                    		<div class="mws-button-row">
                    			<input type="submit" name="submit" value="Submit" class="mws-button red" />
                    			<input type="reset" value="Reset" class="mws-button gray" />
                    		</div>
                    	</form>
                    </div>  	
                </div>

</form>
<?php
	
	echo $core->buildFormJS( 'changeConnection' );
	
?>

<div class="mws-panel grid_8">
<div class="mws-panel-header">
<span class="mws-i-24 i-cog">Past Changes</span>
</div>
<div class="mws-panel-body"><div class="mws-panel-content">
	
	<?php
	
		$query = $db->query( "SELECT * FROM connection_info ORDER BY id DESC LIMIT 1, 3" );
		
		$i = "a";
		
		while( $array = $db->assoc( $query ) ) {
			
			$query2 = $db->query( "SELECT * FROM users WHERE id = '{$array['user']}'" );
			$array2 = $db->assoc( $query2 );
			
			echo "<div class=\"row {$i}\">";
			
			echo "Change made by <strong>{$array2['username']}</strong> ({$array['ip']}):";
			echo "<br />";
			echo "<strong>IP:</strong> {$array['host']}";
			echo "<br />";
			echo "<strong>Port:</strong> {$array['port']}";
			echo "<br />";
			echo "<strong>Password:</strong> {$array['password']}";
			echo "<br /><br />";
			echo "<hr />";
			
			echo "</div>";
			
			$i++;
			
			if( $i == "c" ) {
			
				$i = "a";
			
			}
		
		}
	
	?>
</div></div>
</div>