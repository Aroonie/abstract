<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }
	
	$q		=	$db->query( "SELECT * FROM donators ORDER BY `id` DESC" );
	$n		=	$db->num( $q );
	$q2		=	$db->query( "SELECT * FROM donators WHERE (`id`='{$core->clean($_GET['id'])}')" );
	$a2		=	$db->arr( $q2 );
	$n2		=	$db->num( $q2 );

?>
	<style type="text/css">
		textarea {
			width: 400px;
			height: 150px;
		}
		
		input[type=text]{
			width: 400px;
		}
	</style>

	<div class="box">

		<div class="square title">
			<strong>Manage Donators</strong>
		</div>
		
		<input type="button" name="new" value="New Donator" onclick="window.location.href='?do=new';" />
		
		<?php
		
			if( $_GET['do'] == "delete"  )
			{
				$id		=	$core->clean( $_GET['id'] );
				$db->query( "DELETE FROM `donators` WHERE (`id`='{$id}')" );
				echo "<div class=\"square good\">";
				echo "<strong>Success!</strong>";
				echo "<br />";
				echo "Donator successfully removed from the database.";
				echo "</div>";
			}
			
			if( $n == 0 )
				{
					echo "<div class=\"square bad\">";
					echo "<strong>Error</strong>";
					echo "<br />";
					echo "There are currently no donators in the database.";
					echo "</div>";
				}
				
			else
				{
					
				
		?>
		
		<p>Here you can add new donators and manage the existing ones.</p>
		
		<table width="100%">
			<tr>
				<th>Habbo Name</th>
				<th>Options</th>			
			</tr>
		<?php
		
			while( $items = $db->assoc($q) )
			{
				echo "<tr>";
				
					echo "<td width=\"45%\">{$items['habboname']}</td>";
					echo "<td width=\"45%\" style=\"text-align: center;\">
                		<a href=\"?do=delete&id={$items['id']}\"><img src=\"_img/request_uncheck.png\" /></a>
                        <a href=\"?do=edit&id={$items['id']}\"><img src=\"_img/pencil.png\" /></a> 
					</td>";
				
				echo "</tr>";
			}
	
		?>
		</table>
		
		
	</div>

		<?php
	}
	
	if( $_GET['do'] == "edit" )
	{
		echo "<div class=\"box\">";
			echo "<div class=\"square title\">";
				echo "<strong>Edit the donator: <em>{$a2['habboname']}</em></strong>";
			echo "</div>";
			
			if( isset( $_POST['submit'] ) )
			{
				$habboname	=	$core->clean( $_POST['habboname'] );
				$habboimage	=	$core->clean( $_POST['habboimage'] );
				$id			=	$core->clean( $_GET['id'] );
				$db->query( "UPDATE `donators` SET `habboname`='{$habboname}', `habboimg`='{$habboimage}' WHERE (`id`='{$id}')" );
				echo "<div class=\"square good\">";
				echo "<strong>Success!</strong>";
				echo "<br />";
				echo "Edited the donator {$a2['habboname']} successfully.";
				echo "</div>";
			}
			echo "<form method=\"POST\" action=\"\">";
			
				echo "Habbo Name: <br />";
				echo "<input type=\"text\" name=\"habboname\" value=\"{$a2['habboname']}\" />";
				
				echo "<br /><br />";
				
				echo "Habbo Image: <br />";
				echo "<textarea name=\"habboimage\">{$a2['habboimg']}</textarea>";
				
				echo "<br /><br />";
				
				echo "<input type=\"submit\" name=\"submit\" value=\"Update\" />";
			
			echo "</form>";
			
		echo "</div>";
	}
	
	if( $_GET['do'] == "new" )
	{
		echo "<div class=\"box\">";
			echo "<div class=\"square title\">";
				echo "<strong>New Donator</strong>";
			echo "</div>";
			
			if( isset( $_POST['submit'] ) )
			{
				$habboname	=	$core->clean( $_POST['habboname'] );
				$habboimage	=	$core->clean( $_POST['habboimage'] );
				$id			=	$core->clean( $_GET['id'] );
				$db->query( "INSERT INTO `donators` (`habboname`, `habboimg`) VALUES ('{$habboname}', 'http://www.habbo.com/habbo-imaging/avatarimage?user={$habboname}&action=std&direction=4&head_direction=3&gesture=sml&size=s&actio')" );
				echo "<div class=\"square good\">";
				echo "<strong>Success!</strong>";
				echo "<br />";
				echo "Added the new donator successfully.";
				echo "</div>";
				
			}
			echo "<form method=\"POST\" action=\"\">";
			
				echo "Habbo Name: <br />";
				echo "<input type=\"text\" name=\"habboname\" />";
				
				echo "<br /><br />";
				
				echo "<input type=\"submit\" name=\"submit\" value=\"Create Donator\" />";
			
			echo "</form>";
			
			
		echo "</div>";
	}
		?>