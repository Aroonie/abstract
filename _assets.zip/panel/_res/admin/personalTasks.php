 <div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-home">Community & General Administration Tasks</span>
                    </div>
                    <div class="mws-panel-body">
                    	<div class="mws-panel-content">
<strong>
As a Community / General Administrator, we require you to have a mature role within the team, and we expect certain tasks to be completed. This is to ensure that the site runs smoothly and our team is the best it can be. As a Community / General Administrator, we expect this from you:
<br></strong>
<br>
• Take charge of the Radio and Events Managers. Make sure they are doing their tasks, and monitor them for demotions, and the Head DJs/Senior Events Hosts for promotions.
<br>
• In relation to the last point, don’t hesitate to remove a member of staff from the team if you feel as if there is valid reasoning. However, make sure this is discussed with Senior Administration or Ownership if needed.
<br>
• Complete at least 2 slots per week. We don’t think this is much, and we expect it from all of you. If you are unable to do this, let a Senior Admin know.
<br>
• Hold regular meetings with the Radio and Events Managers so they know how well they’re doing, or whether they need to improve. These should be verbal meetings over a Skype call at a convenient time for all staff.
<br>
• Write a weekly written review for the Management team. This should be in depth and include their strengths, weaknesses and improvements for the next week.
<br>
• Be a mature role model when it comes to situations like arguments in the chat. For example, if there were a conflict between a Radio Manager and another member of staff <i>(below in rank)</i>, it would be your duty to get them both into a conversation and sort it out. 


</center>
 </div>
                    </div>
                </div>