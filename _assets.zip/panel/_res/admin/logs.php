<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

?>

<div class="mws-panel grid_8">
   <div class="mws-panel-header">
      <span class="mws-i-24 i-cog">Panel Logs</span>
   </div>
   <div class="mws-panel-body">
<?php
if (isset( $_GET['ryanprune'] )){
		$db->query( "TRUNCATE logs" );
		
		echo "<div class=\"mws-form-message success\" align=\"left\">";
		echo "<strong>Success</strong>";
		echo "<br />";
		echo "Logs Pruned.";
		echo "</div>";
}
?>
    <?php 
         
        $query = $db->query( "SELECT * FROM logs ORDER BY id DESC" ); 
         
        $num   = $db->num( $query ); 
         
        if ( $num == 0 ) {

		echo "<div class=\"mws-form-message error\" align=\"left\">";
		echo "<strong>Whoops...</strong>";
		echo "<br />";
		echo "Either there is an error in our system or there are no logs to view!";
		echo "</div>"; 
         
        } else { 
             echo "<div class=\"mws-panel-content\">";
             
        $j = "a"; 

        while( $array = $db->assoc( $query ) ) { 
         
                $query2 = $db->query( "SELECT * FROM users WHERE username = '{$array['username']}'" );  
                    $user  = $db->assoc( $query2 ); 
                    $check = $db->num( $query2 ); 


                if( $check != 0 ) { 
                    $query3 = $db->query( "SELECT * FROM usergroups WHERE id = '{$user['displaygroup']}'" );  
                       $usergroup = $db->assoc( $query3 );  

                    $user['usergroup'] = $usergroup;  
                    $user['fullusername'] = "<strong><span style=\"olor: #{$usergroup['colour']}\">" . $user['username'] . "</span></strong>"; 
                     
                    } else { 
                     
                           $user['fullusername'] = "<strong><span style=\"color: #F5A9A9\">" . $array['username'] . "</span></strong> (User Does Not Exist)"; 
                 
                } 

            echo "<div style=\"background: #efefef; padding: 10px; margin-top: 5px;\">";
            echo $user['fullusername'];
            echo " (IP Address: ";
            echo $array['ip'];
            echo ") ";
            echo "<br /><strong>Action:</strong> ";
            echo $array['status'];
            echo "<br /><strong>Date & Time:</strong> ";
            echo $array['date'];

            echo "</div>";

            $j++; 

            if( $j == "c" ) { 

                $j = "a"; 

            } 

        } 
    } 
    ?> 
      </div>
   </div>
</div>
<br clear="all"/>