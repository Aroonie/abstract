<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

?>
            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-cog">Post Update</span>
                    </div>
                    <div class="mws-panel-body">
                    	<form action="" method="post" id="siteAlert" class="mws-form">
		<?php
		// Check if the form has been submitted
			if( $_POST['submit'] ) {

				try {
					$type       = $core->clean( $_POST['type'] );
					$message    = $core->clean( $_POST['message'] );
					$date       = time();

					$querycheck = $db->query( "SELECT * FROM update_types WHERE id = '{$type}'" );
					$datacheck  = $db->assoc( $querycheck );

					if( !$type or !$message ) {

						throw new Exception( "All fields are required." );

					}
					else if( !$datacheck['name'] ) {

						throw new Exception( "We were unable to find this update type, please try again." );

					}
					else {


						$db->query( "INSERT INTO updates VALUES (NULL, '{$user->data['id']}', '{$_SERVER['REMOTE_ADDR']}', '{$type}', '{$message}', '{$date}');" );


						echo "<div class=\"square good\">";
						echo "<strong>Success</strong>";
						echo "<br />";
						echo "Update posted!";
						echo "</div>";

					}

				}
				catch( Exception $e ) {

					echo "<div class=\"square bad\">";
					echo "<strong>Error</strong>";
					echo "<br />";
					echo $e->getMessage();
					echo "</div>";

				}

			}
?>
   		<div class="mws-form-inline">
   			<div class="mws-form-row">
	   		<?php

	   			$getTypes = $db->query( "SELECT * FROM update_types" );
	   			while( $array55 = $db->assoc( $getTypes ) ) {
                    $types[$array55['id']]  = $array55['name'];
				}
				echo $core->buildField( "select",
                                        "required",
                                        "type",
                                        "Type",
                                        "Type of update.",
                                        $types );
				echo $core->buildField( "text",
										"required",
										"message",
										"Message",
										"The message in the update.");
			?>
           	</div>
		   	</div>
                    		<div class="mws-button-row">
                    			<input type="submit" name="submit" value="Submit" class="mws-button red" />
                    			<input type="reset" value="Reset" class="mws-button gray" />
                    		</div>
                    	</form>
                    </div>    	
                </div>
<?php
	echo $core->buildFormJS('addUpdate');
?>