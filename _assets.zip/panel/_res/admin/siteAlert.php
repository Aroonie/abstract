<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

?>
            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-cog">Send Site Wide Message</span>
                    </div>
                    <div class="mws-panel-body">
                    	<form action="" method="post" id="siteAlert" class="mws-form">
		<?php

			if( $_POST['submit'] ) {

				try {

					$alert = $core->clean( $_POST['alert'] );

					if( !$alert ) {

						throw new Exception( "All fields are required." );

					}
					else {
                                                $time = time();
						$db->query( "INSERT INTO site_alerts VALUES (NULL, '{$alert}', '{$user->data['id']}', '{$time}');" );

						echo "<div class=\"mws-form-message success\">Success!<ul><li>Site Alert successfully sent!</li></ul></div>";

					}

				}
				catch( Exception $e ) {
	
					echo "<div class=\"mws-form-message error\">";
					echo "Error";
					echo "<ul><li>";
					echo $e->getMessage();
					echo "</li></ul></div>";

				}

			}

		?>
                    		<div class="mws-form-inline">
                    			<div class="mws-form-row">
                    				<label>Site Alert</label>
                    				<div class="mws-form-item medium">
                    						<input type="text" class="mws-textinput" id="alert" name="alert" />
                    				</div>
                    			</div>
                    		</div>
                    		<div class="mws-button-row">
                    			<input type="submit" name="submit" value="Submit" class="mws-button red" />
                    			<input type="reset" value="Reset" class="mws-button gray" />
                    		</div>
                    	</form>
                    </div>    	
                </div>

<?php
	echo $core->buildFormJS('siteAlert');
?>