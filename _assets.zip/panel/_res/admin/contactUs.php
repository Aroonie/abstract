<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

?>
            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-table-1">Contact Us</span>
                    </div>
                    <div class="mws-panel-body">
                        <table class="mws-table">
                            <thead>
                                <tr>
                                    <th>Habbo Name</th>
                                    <th>Message</th>
                                    <th>IP</th>
                                    <th width="60">Controls</th>
                                </tr>
                            </thead>
                            <tbody>
	<?php

                $query = $db->query( "SELECT * FROM contactus ORDER BY id DESC" );
		$num   = $db->num( $query );

		$j = "a";

		while( $array = $db->assoc( $query ) ) {

			echo "<tr class=\"row {$j}\" id=\"contact_{$array['id']}\">";

			echo "<td>" . $array['habbo'] . "</td>";
			echo "<td>" . $array['contact'] . "</td>";
                        echo "<td>" . $array['ip'] . "</td>";
                        echo "<td>";
			echo "<center><a href=\"#\" onclick=\"Radi.deleteContactUs('{$array['id']}');\">";
			echo "<img src=\"_img/minus.png\" alt=\"Delete\" />";
			echo "</a></center>";
			echo "</td>";

			$j++;

			if( $j == "c" ) {

				$j = "a";

			}

		}

		if( $num == 0 ) {

			echo "<div class=\"mws-form-message error\">";
			echo "Sorry";
			echo "<ul><li>";
			echo "Nobody wants to contact us :(";
			echo "</li></ul></div>";

		}

	?>
                            </tbody>
                        </table>
                    </div>
                </div>