<?php
	
	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

	include_once( "./cloudflare.php" );
	
?>
<div class="box">

	<div class="square title" style="background-color: #<?php echo $arrayColor[colour]; ?> !important;">
		<strong>Manage DEV Mode (Forum)</strong>
	</div>

	<div class="content">

<?php

if (isset( $_GET['enable'] )){

 $url = "http://www.imandings.com/CLOUDFLARE-MANAGE/DEV_MODE.php";
 $postfields["passcode"] = "WrxXJgL9z7AyxVqWv";
 $postfields["action"] = "1"; 
 $postfields["domain"] = "madhabboforum.com";
 $ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, $url);
 curl_setopt($ch, CURLOPT_POST, 1);
 curl_setopt($ch, CURLOPT_TIMEOUT, 100);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 curl_setopt($ch, CURLOPT_POSTFIELDS, $postfields);
 $data = curl_exec($ch);
 curl_close($ch);

if ($data == "Done")
{

$db->query( "INSERT INTO management_logs VALUES (NULL, '{$user->data['username']}', '{$_SERVER['REMOTE_ADDR']}', '{$date}', 'Enabled Forum Dev Mode.', 'Success.')" );
		
			echo "<div class=\"square good\" align=\"left\">";
			echo "<strong>Success</strong>";
			echo "<br />";
			echo "Forum DEV Mode Enabled (It will disable automatically in 3 hours).";
			echo "</div>";
}
else
{

$db->query( "INSERT INTO management_logs VALUES (NULL, '{$user->data['username']}', '{$_SERVER['REMOTE_ADDR']}', '{$date}', 'Enabled Forum Dev Mode.', 'Fail.')" );
		
			echo "<div class=\"square bad\" align=\"left\">";
			echo "<strong>Error</strong>";
			echo "<br />";
			echo "Failed to enable forum dev mode.";
			echo "</div>";

}


} else if (isset( $_GET['disable'] )){

 $url = "http://www.imandings.com/CLOUDFLARE-MANAGE/DEV_MODE.php";
 $postfields["passcode"] = "WrxXJgL9z7AyxVqWv";
 $postfields["action"] = "0"; 
 $postfields["domain"] = "madhabboforum.com";
 $ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, $url);
 curl_setopt($ch, CURLOPT_POST, 1);
 curl_setopt($ch, CURLOPT_TIMEOUT, 100);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 curl_setopt($ch, CURLOPT_POSTFIELDS, $postfields);
 $data = curl_exec($ch);
 curl_close($ch);

if ($data == "Done")
{

$db->query( "INSERT INTO management_logs VALUES (NULL, '{$user->data['username']}', '{$_SERVER['REMOTE_ADDR']}', '{$date}', 'Disabled Forum Dev Mode.', 'Success.')" );
		
			echo "<div class=\"square good\" align=\"left\">";
			echo "<strong>Success</strong>";
			echo "<br />";
			echo "Forum DEV Mode Disabled.";
			echo "</div>";
}
else
{

$db->query( "INSERT INTO management_logs VALUES (NULL, '{$user->data['username']}', '{$_SERVER['REMOTE_ADDR']}', '{$date}', 'Disabled Forum Dev Mode.', 'Fail.')" );
		
			echo "<div class=\"square bad\" align=\"left\">";
			echo "<strong>Error</strong>";
			echo "<br />";
			echo "Failed to disable forum dev mode.";
			echo "</div>";

}

}

?>

<i>Use this tool to manage DEV MODE FOR THE FORUM on CloudFlare. (Turn on to update cached files on the website) (<i>This only affects MADHABBOFORUM.com</i>)</i><br><br>
<form action="?enable" method="post">
		
		<input type="submit" class="button red" value="ENABLE">
		
</form><br />
<form action="?disable" method="post">
		
		<input type="submit" class="button red" value="DISABLE">
		
</form>
</center>

	</div>

</div>