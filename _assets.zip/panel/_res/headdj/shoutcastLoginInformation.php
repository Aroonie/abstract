<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

?>
<style type="text/css">
	a {
		text-decoration: none;
		color: black;
	}
</style>
                <div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-pacman-ghost">Shoutcast Login</span>
                    </div>
                    <div class="mws-panel-body">
                    	<div class="mws-panel-content">
<div class="box">
	</div>

	<div class="content">
<p><b>Username:</b> MHAutoDJKick<br/>
<b>Password:</b> fewUKghuhef3y2edfhhuhudh<br/>
<b>Login URL:</b> <a href="http://sc.madhabbo.com:2199/" target="_blank">Click Here</a><br/>
<strong>Login Information last updated (20/01/16) by Mark</strong></p>

	</div>

</div>
</div>
                    </div>
                </div>