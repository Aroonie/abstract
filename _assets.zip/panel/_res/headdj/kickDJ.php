<?php
	
	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }
	
?>
            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-cog">Kick The DJ</span>
                    </div>
                    <div class="mws-panel-body">
                    	<form action="" method="post" id="changeHabbo" class="mws-form">
		<?php

        if (isset($_POST['submit'])) {

            $infoQ = $db->query("SELECT * FROM connection_info ORDER BY id DESC LIMIT 1");
            $arrayQ = $db->assoc($infoQ);

            $host = $arrayQ['host'];
            $port = $arrayQ['port'];
            $password = $arrayQ['password'];

                $streaminfo = $core->radioInfo("http://{$arrayQ['host']}:{$arrayQ['port']}");

                $servertitle = $streaminfo['streamtitle'];
                $genre = $streaminfo['servergenre'];
                $listeners = $streaminfo['listeners']; //Total Listeners
                $ulisteners = $streaminfo['ulisteners']; //Unique Listeners
                $currentsong = $streaminfo['currentsong'];

                $DJ = $streaminfo['streamtitle'];

                if (strlen($DJ) < 1 ) { $DJ = "No DJ is On Air!"; }



        $fp = @fsockopen($host, $port, $errno, $errstr, 4);
        if (!$fp)
        {

            echo "<div class=\"mws-form-message error\">Error!<ul><li>{$DJ} could not be kicked!</li></ul></div>";
$date  = date("l jS \of F Y h:i:s A");
        $ipAddress = $_SERVER['REMOTE_ADDR'];
$db->query( "INSERT INTO logs VALUES (NULL, '{$user->data['username']}', '{$ipAddress}', '{$date}', 'Failed to kick dj off air')" );
        }
        else
        {
            fputs($fp, "GET /admin.cgi?pass=$password&mode=kicksrc HTTP/1.0\r\nUser-Agent: Mozilla\r\n\r\n");
            fclose($fp);

           echo "<div class=\"mws-form-message success\">Success!<ul><li>{$DJ} successfully kicked!</li></ul></div>";
$date  = date("l jS \of F Y h:i:s A");
        $ipAddress = $_SERVER['REMOTE_ADDR'];
$db->query( "INSERT INTO logs VALUES (NULL, '{$user->data['username']}', '{$ipAddress}', '{$date}', 'Successfully kicked dj off air')" );
        }
        }

		?>
<?php
            $infoQ = $db->query("SELECT * FROM connection_info ORDER BY id DESC LIMIT 1");
            $arrayQ = $db->assoc($infoQ);
            $streaminfo = $core->radioInfo("http://{$arrayQ['host']}:{$arrayQ['port']}");
?>
                    		<div class="mws-form-inline">
                    			<div class="mws-form-row">
                    				<label>Current DJ</label>
                    				<div class="mws-form-item medium">
                    						<input type="text" value="<?php echo $streaminfo['streamtitle']; ?>" class="mws-textinput" disabled />
                    				</div>
                    			</div>
                    		</div>
                    		<div class="mws-button-row">
                    			<input type="submit" name="submit" value="Kick DJ (<?php echo $streaminfo['streamtitle']; ?>)" class="mws-button red" />
                    		</div>
                    	</form>
                    </div>    	
                </div>