
            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-table-1">Manage Events</span>
                    </div>
                    <div class="mws-panel-body">
                        <table class="mws-table">
                            <thead>
                                <tr>
                                    <th>Event Name</th>
                                    <th>Event Date</th>
                                    <th>Event Time</th>
                                    <th>Event Host</th>
                                    <th>Controls</th>
                                </tr>
                            </thead>
                            <tbody>
	<?php

                $query = $db->query( "SELECT * FROM events ORDER BY day, time" );
		$num   = $db->num( $query );

		$j = "a";

		while( $array = $db->assoc( $query ) ) {

			$array['day'] = strtotime( "{$array['day']} november 2010" );
			$array['day'] = date( "l", $array['day'] );

			echo "<tr class=\"row {$j}\" id=\"event_{$array['id']}\">";

			echo "<td>" . $array['name'] . "</td>";
			echo "<td>" . $array['day'] . "</td>";
			echo "<td>" . $array['time'] . "</td>";
			echo "<td>" . $array['host'] . "</td>";
			echo "<td>";
			echo "<center>";
			echo "<a href=\"#\" onclick=\"Radi.deleteEvent('{$array['id']}');\">";
			echo "<img src=\"_img/minus.png\" alt=\"Delete\" />";
			echo "</a>";
			echo "</center>";
			echo "</td>";

			echo "<tr>";

			$j++;

			if( $j == "c" ) {

				$j = "a";

			}

		}

		if( $num == 0 ) {

			echo "<div class=\"square bad\" style=\"margin-bottom: 0px;\">";
			echo "<strong>Sorry</strong>";
			echo "<br />";
			echo "There are no events to manage.";
			echo "</div>";

		}

	?>
                            </tbody>
                        </table>
                    </div>
                </div>