<?php
require_once( "../../_inc/glob.php" ); 
if ( $user->loggedIn ) {
?>
<html>
<head>
<style type="text/css" media="screen">
body {
	background: #ddeef6;
	padding-bottom: 0;
	margin-bottom: 0;
}
body, a, td, th, input, textarea, select {
	font-family: Arial;
	font-size: 12px;
	color: #444;
	text-decoration: none;
}
a {
	font-weight: bold;
}
img {
	border: 0;
}
form {
	padding: 0;
	margin: 0;
}
.box {
	background: #fcfcfc;
	padding: 4px;
	margin-bottom: 10px;
	border: 1px #fcfcfc solid;
	-moz-border-radius: 3px;
	-webkit-border-radius: 3px;
	border-radius: 3px;
}
.box .content {
        background: url(../v3/_images/_boxes/centre_box.PNG);
	padding: 0px 5px 5px 5px;
}
big {
	padding-bottom: 5px;
	display: block;
	color: #8899a1;
	font-size: 15px;
	font-weight: bold;
}
.menuitems {
	margin-top: 5px;
}
.menuitems .a, .row.a, .menuitems .b, .row.b {
	padding: 3px;
	display: block;
	font-weight: normal;
}
.row {
	padding: 5px;
}
.menuitems .a, .row.a {
	background-color: #f3f3f3;
}
.menuitems .b, .row.b {
	background-color: #f8f8f8;
	}
.square {
	border: 1px solid;
	-moz-border-radius: 3px;
	-webkit-border-radius: 3px;
	border-radius: 3px;
	padding: 4px;
	margin-bottom: 5px;
}
.square strong {
	font-size: 12px;
}
.square.menu {
	color: #fff;
	margin-bottom: 0px;
	cursor: pointer;
}
.square.title {
	background-color: #eee;
	color: #444;
	border-color: #eee;
}
.square.good, .help.good {
	background-color: #d9ffcf;
	border-color: #ade5a3;
	color: #1b801b;
}
.square.bad, .help.bad {
	background-color: #ffcfcf;
	border-color: #e5a3a3;
	color: #801b1b;
}
.square.good a, .help.good a, .square.good hr, .help.good hr {
	color: #1b801b;
}
.square.bad a, .help.bad a, .square.bad hr, .help.bad hr {
	color: #801b1b;
}
.help {
	padding: 5px;
	font-size: 12px;
	height: 16px;
	position: relative;
	left: -9px;
	border: 1px #ccc solid;
	border-bottom-width: 2px;
	-moz-border-radius-topright: 3px;
	-webkit-border-top-right-radius: 3px;
	border-radius-topright: 3px;
	-webkit-border-bottom-right-radius: 3px;
	-webkit-border-radius-bottomright: 3px;
	border-radius-bottomright: 3px;
}
.help.grey {
	background-color: #eee;
}
input, textarea, select {
	border: 1px #e0e0e0 solid;
	border-bottom-width: 2px;
	-moz-border-radius: 3px;
	-webkit-border-radius: 3px;
	border-radius: 3px;
	padding: 5px;
	font-size: 12px;
	font-weight: bold;
	outline: 0;
}
input[type="text"], input[type="password"] {
	width: 300px;	
}
input:focus {
	border-color: #ccc;
	background-color: #fafafa;
}
input[type=submit], input.button {
	color: #888;
	border-color: #ddd;
	background: #f0f0f0;
	cursor: pointer;
	padding: 3px;
}
input[type=submit]:hover, input.button:hover {
	background-color: #e6e6e6;
	border-color: #d6d6d6;
}
input[type=submit].green, input.button.green {
	background-color: #d9ffcf;
	border-color: #ade5a3;
	color: #1b801b;			
}
input[type=submit].red, input.button.red {
	background-color: #ffcfcf;
	border-color: #e5a3a3;
	color: #801b1b;		
}
td.label {
	//width: 25%;
	//text-align: right;
	padding-right: 10px;
	width: 100px;
}
td.field {
	//width: 200px;
	//text-align: right;
	//text-align: left;
	width: 1%;
}
.bbcode-quote {
	background-color: #F5F5F5;
	border: 1px solid #D8D8D8;
	-moz-border-radius: 3px;
	-webkit-border-radius: 3px;
	border-radius: 3px;
	margin: 3px 3px 10px;
	padding: 5px;
}
div.pagination {
	padding: 3px;
	text-align: right;
	width: auto;
}
div.pagination a {
	padding: 2px;
	border: 1px solid #FFF;
	border-bottom: 2px solid #FFF;
	text-decoration: none; /* no underline */
	border-left: none;
	border-right: none;	
	color: #444;
}
div.pagination a:hover, div.pagination a:active {
	color: #FFF;
	background-color: #444;
	border-bottom: 2px solid #444;
	border-left: none;
	border-right: none;	
}
div.pagination a.current {
	padding: 2px;
	border: 1px solid #FFF;
	border-bottom: 2px solid #444;
	font-weight: bold;
	color: #444;
	border-left: none;
	border-right: none;
}
div.pagination a.current:hover {
	color: #FFF;
}
</style>
</head>

<body>
<div class="wrapper">
<div class="box">
Hello <b><?php echo $user->data['fullUsername']; ?></b>, don't see the event you wish to book? Send a message to management, and it may get added!
<br>
<br>
Are you sure you would like to book an event at this time? As soon as 2 hours approaches before your slot, you can't unbook it. So be sure!
<br><br>
<?php
if($_POST['Book']){
					$event  = $core->clean( $_POST['event'] );
					$day    = $core->clean( $_POST['day'] );
					$time   = $core->clean( $_POST['time'] );
					$host   = $core->clean( $user->data['id'] );

					if( !$event or !$day or !$time or !$host ) {

						throw new Exception( "All fields are required." );

					}
					else
					{
						$db->query( "INSERT INTO events_timetable VALUES (NULL, '{$day}', '{$time}', '{$host}', '{$event}', '0');" );
?>
<div class="square good">Your event request has been submitted to the Events Manager and Senior Events for approval. Please allow up to 24 hours for a response.</div>
<?php
					}

}else{
} 
?>
<br>
<form method="post" action="">
<select name="event" style="outline:none;width:auto;margin:0;">
					<?php
						
						$query3 = $db->query( "SELECT * FROM events_types ORDER BY name ASC" );
						
						while( $array3 = $db->assoc( $query3 ) ) {
						
					?>
					
					<option value="<?php echo $array3['name']; ?>">
						<?php echo $array3['name']; ?>
					</option>
					
					
					<?php
						
						}
						
					?>
</select>
<input type="hidden" value="<?php echo $_GET['day']; ?>" name="day">
<input type="hidden" value="<?php echo $_GET['time']; ?>" name="time">
<input type="submit" name="Book" value="Book">
</form>
</div>
</div>
</body>
</html>
<?php } ?>