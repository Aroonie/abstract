<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

	if( $_GET['id'] ) {

		$id = $core->clean( $_GET['id'] );

		$query = $db->query( "SELECT * FROM events WHERE id = '{$id}'" );
		$data  = $db->assoc( $query );

		$editid = $data['id'];

	}

?>

<style>
select {
   width: 860px;
}
</style>

            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-home">Add Event</span>
                    </div>
                    <div class="mws-panel-body">
                    	<form action="" method="post" id="addEvent" class="mws-form">

		<?php

			if( $_POST['submit'] ) {

				try {

					$name  = $core->clean( $_POST['name'] );
					$day   = $core->clean( $_POST['day'] );
					$time  = $core->clean( $_POST['time'] );
					$host  = $core->clean( $_POST['host'] );

					if( !$name or !$day or !$time or !$host ) {

						throw new Exception( "All fields are required." );

					}
					else {

						if( $editid ) {

							$db->query( "UPDATE events SET name = '{$name}', day = '{$day}', time = '{$time}', host = '{$host}' WHERE id = '{$editid}'" );

						}
						else {

							$db->query( "INSERT INTO events VALUES (NULL, '{$name}', '{$day}', '{$time}', '{$host}');" );

						}

						echo "<div class=\"mws-form-message success\">Success!<ul><li>Event successfully added!</li></ul></div>";

					}

				}
				catch( Exception $e ) {

					echo "<div class=\"mws-form-message error\">";
					echo "Error";
					echo "<ul><li>";
					echo $e->getMessage();
					echo "</li></ul></div>";

				}

			}

		?>

                    		<div class="mws-form-inline">
                    			<div class="mws-form-row">
                    				<label>Event Name</label>
                    				<div class="mws-form-item medium">
                    						<input type="text" class="mws-textinput" id="name" name="name" />
                    				</div>
                    			</div>
                    			<div class="mws-form-row">

<?php
				$days = array( 1 => "Monday",
							   2 => "Tuesday",
							   3 => "Wednesday",
							   4 => "Thursday",
							   5 => "Friday",
							   6 => "Saturday",
							   7 => "Sunday" );

				foreach( $days as $key => $value ) {

					if( $key == $data['day'] ) {

						$days[$key . '_active'] = $value;
						
						unset( $days[$key] );

					}

				}

                    		echo "<label>Event Day</label>";
                    		echo "<div class=\"mws-form-item medium\">";
				echo $core->buildField( "select",
										"required",
										"day",
										"",
										"",
										$days );
                    		echo "</div>";

?>

                    			</div>
                    			<div class="mws-form-row">
                    				<label>Event Time</label>
                    				<div class="mws-form-item medium">
                    						<select id="time" name="time">
	                    						<option>00:00 GMT</option>
                    							<option>01:00 GMT</option>
                    							<option>02:00 GMT</option>
                    							<option>03:00 GMT</option>
                    							<option>04:00 GMT</option>
                    							<option>05:00 GMT</option>
                    							<option>06:00 GMT</option>
                    							<option>07:00 GMT</option>
                    							<option>08:00 GMT</option>
                    							<option>09:00 GMT</option>
                    							<option>10:00 GMT</option>
                    							<option>11:00 GMT</option>
                    							<option>12:00 GMT</option>
                    							<option>13:00 GMT</option>
                    							<option>14:00 GMT</option>
                    							<option>15:00 GMT</option>
                    							<option>16:00 GMT</option>
                    							<option>17:00 GMT</option>
                    							<option>18:00 GMT</option>
                    							<option>19:00 GMT</option>
                    							<option>20:00 GMT</option>
                    							<option>21:00 GMT</option>
                    							<option>22:00 GMT</option>
                    							<option>23:00 GMT</option>
                    						</select>
                    				</div>
                    			</div>
                    			<div class="mws-form-row">
                    				<label>Habbo Name</label>
                    				<div class="mws-form-item medium">
                    						<input type="text" class="mws-textinput" id="host" name="host" />
                    				</div>
                    			</div>
                    		</div>
                    		<div class="mws-button-row">
                    			<input type="submit" name="submit" value="Submit" class="mws-button red" />
                    			<input type="reset" value="Reset" class="mws-button gray" />
                    		</div>
                    	</form>
                    </div>    	
                </div>

<?php
	echo $core->buildFormJS('addEvent');

?>