<?php
	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }
?>
            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-table-1">Events Timetable // Please book all slots in GMT! - <I>(GMT time can be found at the top right of your screen!)</i></span>
                    </div>
                    <div class="mws-panel-body">
                        <table class="mws-table">

                            <thead>
                                <tr>
                                    <th style="text-align: center;" width="12.5%">Time</th>
                                    <th style="text-align: center;" width="12.5%" >Monday</th>
                                    <th style="text-align: center;" width="12.5%" >Tuesday</th>
                                    <th style="text-align: center;" width="12.5%" >Wednesday</th>
                                    <th style="text-align: center;" width="12.5%" >Thursday</th>
                                    <th style="text-align: center;" width="12.5%" >Friday</th>
                                    <th style="text-align: center;" width="12.5%" >Saturday</th>
                                    <th style="text-align: center;" width="12.5%" >Sunday</th>
                                </tr>
                            </thead>
<?php

        for ($l = 0; $l <=23; $l++){
                                $m = $l + 1;
                                if( $l < 10 ) { 
                                $time = "0{$l}:00"; 
                                } 
                                else { 
                                    $time = "{$l}:00"; 
                                } 
                                if( $m < 10 ) { 
                                    $time2 = "0{$m}:00"; 
                                 } 
                                elseif( $m == 24 ) { 
                                    $time2 = "00:00"; 
                                } 
                                else { 
                                    $time2 = "{$m}:00"; 
                                }
                                ?>
                                <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">
                                       <?php echo "". $time . " - " . $time2 . ""; ?>
                                    </td>

<?php
}
	for( $i = 1; $i <= 7; $i++ ) {
		$day = strtotime( "{$i} november 2010" );
		$day = date( "l", $day );
?>
				    <td style="text-align: center;">
				<?php

					for( $j = 0; $j <= 23; $j++ ) {
						
						if( $j < 10 ) {
						
							$time = "0{$j}:00";
						
						}
						else {
						
							$time = "{$j}:00";
						
						}

if ($j == "0"){ $j = "00"; }
if ($j == "1"){ $j = "01"; }
if ($j == "2"){ $j = "02"; }
if ($j == "3"){ $j = "03"; }
if ($j == "4"){ $j = "04"; }
if ($j == "5"){ $j = "05"; }
if ($j == "6"){ $j = "06"; }
if ($j == "7"){ $j = "07"; }
if ($j == "8"){ $j = "08"; }
if ($j == "9"){ $j = "09"; }
						
						$query = $db->query( "SELECT * FROM events_timetable WHERE day = '{$i}' AND time = '{$j}' AND approved = '1'" );
						$array = $db->assoc( $query );
						$num   = $db->num( $query );

						$query_1 = $db->query( "SELECT * FROM events_timetable WHERE day = '{$i}' AND time = '{$j}' AND approved = '0'" );
						$array_1 = $db->assoc( $query_1 );
						$num_1   = $db->num( $query_1 );

						$query2 = $db->query( "SELECT * FROM users WHERE id = '{$array['host']}'" );
						$array2 = $db->assoc( $query2 );

						$query3 = $db->query( "SELECT * FROM usergroups WHERE id = '{$array2['displaygroup']}'" );
						$array3 = $db->assoc( $query3 );

						echo "<div style=\"padding: 3px;\">";
						
						
						if( $num == 0 ) {

echo "<a href=\"_res/events/timetable_popup.php?time={$j}&day={$i}\" class=\"lightview\" data-lightview-type=\"iframe\" data-lightview-options=\"width: 500, height: 220\" id=\"slot_{$i}_{$j}\">Book</a>";
if ($num_1 != 0){ echo " ({$num_1})"; }
						
						}
						elseif( $array['host'] == $user->data['id'] or $user->hasGroup( '4' ) or $user->hasGroup( '5' ) ) {
							
							echo "<a id=\"slot_{$i}_{$j}\" href=\"#\" onclick=\"Radi.bookEventSlot('{$i}','{$j}'); return false;\" style=\"color: #{$array3['colour']}\">";
							echo $array2['username'];
							echo "</a>";
						
						} else {
							
							echo "<span style=\"color: #{$array3['colour']}; font-weight: bold;\"><b>";
							echo $array2['username'];
							echo "</b></span>";
							
						}
						
						echo "</div>";
						
						
						}
					
				?>

				    </td>
                                  <?php  }  ?>
				</tr>
                            </tbody>
                        </table>
                    </div>
                </div>