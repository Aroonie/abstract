<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

?>
<style type="text/css">
	a {
		text-decoration: none;
		color: black;
	}
</style>
                <div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-camera">Image Uploader</span>
                    </div>
                    <div class="mws-panel-body">
                    	<div class="mws-panel-content">
<div class="box">
	</div>

	<div class="content">

<strong>Username: </strong>MadHabbo<br />
<strong>Password: </strong>#jrcd_5RkRwD_e3P<br />
<strong>Link: </strong><a href="http://madhabbo.com/staffuploader">Staff Uploader</a>




	</div>

</div>
</div>
                    </div>
                </div>