<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }
	
?>
            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-table-1">Time Converter</span>
                    </div>
                    <div class="mws-panel-body">
                        <table class="mws-table">
                            <thead>
                                <tr>
                                    <th style="text-align: center;" width="12.5%" >BST/GMT</th>
                                    <th style="text-align: center;" width="12.5%" >EDT</th>
                                    <th style="text-align: center;" width="12.5%" >EST/CDT</th>
                                    <th style="text-align: center;" width="12.5%" >CST/MDT</th>
                                    <th style="text-align: center;" width="12.5%" >MST/PDT</th>
                                    <th style="text-align: center;" width="12.5%" >PST</th>
                                </tr>
                            </thead>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">00:00</td>
                                    <td width="12.5%" style="text-align: center;">20:00</td>
                                    <td width="12.5%" style="text-align: center;">19:00</td>
                                    <td width="12.5%" style="text-align: center;">18:00</td>
                                    <td width="12.5%" style="text-align: center;">17:00</td>
                                    <td width="12.5%" style="text-align: center;">16:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">01:00</td>
                                    <td width="12.5%" style="text-align: center;">21:00</td>
                                    <td width="12.5%" style="text-align: center;">20:00</td>
                                    <td width="12.5%" style="text-align: center;">19:00</td>
                                    <td width="12.5%" style="text-align: center;">18:00</td>
                                    <td width="12.5%" style="text-align: center;">17:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">02:00</td>
                                    <td width="12.5%" style="text-align: center;">22:00</td>
                                    <td width="12.5%" style="text-align: center;">21:00</td>
                                    <td width="12.5%" style="text-align: center;">20:00</td>
                                    <td width="12.5%" style="text-align: center;">19:00</td>
                                    <td width="12.5%" style="text-align: center;">18:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">03:00</td>
                                    <td width="12.5%" style="text-align: center;">23:00</td>
                                    <td width="12.5%" style="text-align: center;">22:00</td>
                                    <td width="12.5%" style="text-align: center;">21:00</td>
                                    <td width="12.5%" style="text-align: center;">20:00</td>
                                    <td width="12.5%" style="text-align: center;">19:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">04:00</td>
                                    <td width="12.5%" style="text-align: center;">00:00</td>
                                    <td width="12.5%" style="text-align: center;">23:00</td>
                                    <td width="12.5%" style="text-align: center;">22:00</td>
                                    <td width="12.5%" style="text-align: center;">21:00</td>
                                    <td width="12.5%" style="text-align: center;">20:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">05:00</td>
                                    <td width="12.5%" style="text-align: center;">01:00</td>
                                    <td width="12.5%" style="text-align: center;">00:00</td>
                                    <td width="12.5%" style="text-align: center;">23:00</td>
                                    <td width="12.5%" style="text-align: center;">22:00</td>
                                    <td width="12.5%" style="text-align: center;">21:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">06:00</td>
                                    <td width="12.5%" style="text-align: center;">02:00</td>
                                    <td width="12.5%" style="text-align: center;">01:00</td>
                                    <td width="12.5%" style="text-align: center;">00:00</td>
                                    <td width="12.5%" style="text-align: center;">23:00</td>
                                    <td width="12.5%" style="text-align: center;">22:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">07:00</td>
                                    <td width="12.5%" style="text-align: center;">03:00</td>
                                    <td width="12.5%" style="text-align: center;">02:00</td>
                                    <td width="12.5%" style="text-align: center;">01:00</td>
                                    <td width="12.5%" style="text-align: center;">00:00</td>
                                    <td width="12.5%" style="text-align: center;">23:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">08:00</td>
                                    <td width="12.5%" style="text-align: center;">04:00</td>
                                    <td width="12.5%" style="text-align: center;">03:00</td>
                                    <td width="12.5%" style="text-align: center;">02:00</td>
                                    <td width="12.5%" style="text-align: center;">01:00</td>
                                    <td width="12.5%" style="text-align: center;">00:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">09:00</td>
                                    <td width="12.5%" style="text-align: center;">05:00</td>
                                    <td width="12.5%" style="text-align: center;">04:00</td>
                                    <td width="12.5%" style="text-align: center;">03:00</td>
                                    <td width="12.5%" style="text-align: center;">02:00</td>
                                    <td width="12.5%" style="text-align: center;">01:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">10:00</td>
                                    <td width="12.5%" style="text-align: center;">06:00</td>
                                    <td width="12.5%" style="text-align: center;">05:00</td>
                                    <td width="12.5%" style="text-align: center;">04:00</td>
                                    <td width="12.5%" style="text-align: center;">03:00</td>
                                    <td width="12.5%" style="text-align: center;">02:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">11:00</td>
                                    <td width="12.5%" style="text-align: center;">07:00</td>
                                    <td width="12.5%" style="text-align: center;">06:00</td>
                                    <td width="12.5%" style="text-align: center;">05:00</td>
                                    <td width="12.5%" style="text-align: center;">04:00</td>
                                    <td width="12.5%" style="text-align: center;">03:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">12:00</td>
                                    <td width="12.5%" style="text-align: center;">08:00</td>
                                    <td width="12.5%" style="text-align: center;">07:00</td>
                                    <td width="12.5%" style="text-align: center;">06:00</td>
                                    <td width="12.5%" style="text-align: center;">05:00</td>
                                    <td width="12.5%" style="text-align: center;">04:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">13:00</td>
                                    <td width="12.5%" style="text-align: center;">09:00</td>
                                    <td width="12.5%" style="text-align: center;">08:00</td>
                                    <td width="12.5%" style="text-align: center;">07:00</td>
                                    <td width="12.5%" style="text-align: center;">06:00</td>
                                    <td width="12.5%" style="text-align: center;">05:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">14:00</td>
                                    <td width="12.5%" style="text-align: center;">10:00</td>
                                    <td width="12.5%" style="text-align: center;">09:00</td>
                                    <td width="12.5%" style="text-align: center;">08:00</td>
                                    <td width="12.5%" style="text-align: center;">07:00</td>
                                    <td width="12.5%" style="text-align: center;">06:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">15:00</td>
                                    <td width="12.5%" style="text-align: center;">11:00</td>
                                    <td width="12.5%" style="text-align: center;">10:00</td>
                                    <td width="12.5%" style="text-align: center;">09:00</td>
                                    <td width="12.5%" style="text-align: center;">08:00</td>
                                    <td width="12.5%" style="text-align: center;">07:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">16:00</td>
                                    <td width="12.5%" style="text-align: center;">12:00</td>
                                    <td width="12.5%" style="text-align: center;">11:00</td>
                                    <td width="12.5%" style="text-align: center;">10:00</td>
                                    <td width="12.5%" style="text-align: center;">09:00</td>
                                    <td width="12.5%" style="text-align: center;">08:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">17:00</td>
                                    <td width="12.5%" style="text-align: center;">13:00</td>
                                    <td width="12.5%" style="text-align: center;">12:00</td>
                                    <td width="12.5%" style="text-align: center;">11:00</td>
                                    <td width="12.5%" style="text-align: center;">10:00</td>
                                    <td width="12.5%" style="text-align: center;">09:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">18:00</td>
                                    <td width="12.5%" style="text-align: center;">14:00</td>
                                    <td width="12.5%" style="text-align: center;">13:00</td>
                                    <td width="12.5%" style="text-align: center;">12:00</td>
                                    <td width="12.5%" style="text-align: center;">11:00</td>
                                    <td width="12.5%" style="text-align: center;">10:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">19:00</td>
                                    <td width="12.5%" style="text-align: center;">15:00</td>
                                    <td width="12.5%" style="text-align: center;">14:00</td>
                                    <td width="12.5%" style="text-align: center;">13:00</td>
                                    <td width="12.5%" style="text-align: center;">12:00</td>
                                    <td width="12.5%" style="text-align: center;">11:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">20:00</td>
                                    <td width="12.5%" style="text-align: center;">16:00</td>
                                    <td width="12.5%" style="text-align: center;">15:00</td>
                                    <td width="12.5%" style="text-align: center;">14:00</td>
                                    <td width="12.5%" style="text-align: center;">13:00</td>
                                    <td width="12.5%" style="text-align: center;">12:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">21:00</td>
                                    <td width="12.5%" style="text-align: center;">17:00</td>
                                    <td width="12.5%" style="text-align: center;">16:00</td>
                                    <td width="12.5%" style="text-align: center;">15:00</td>
                                    <td width="12.5%" style="text-align: center;">14:00</td>
                                    <td width="12.5%" style="text-align: center;">13:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">22:00</td>
                                    <td width="12.5%" style="text-align: center;">18:00</td>
                                    <td width="12.5%" style="text-align: center;">17:00</td>
                                    <td width="12.5%" style="text-align: center;">16:00</td>
                                    <td width="12.5%" style="text-align: center;">15:00</td>
                                    <td width="12.5%" style="text-align: center;">14:00</td>
                                </tr>
                               <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">23:00</td>
                                    <td width="12.5%" style="text-align: center;">19:00</td>
                                    <td width="12.5%" style="text-align: center;">18:00</td>
                                    <td width="12.5%" style="text-align: center;">17:00</td>
                                    <td width="12.5%" style="text-align: center;">16:00</td>
                                    <td width="12.5%" style="text-align: center;">15:00</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>