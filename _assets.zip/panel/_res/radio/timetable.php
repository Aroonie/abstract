<?php
	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }
	if( $user->hasGroup( '5' ) ) {
?>

<div class="mws-panel grid_8">
<div class="mws-panel-header">
<span class="mws-i-24 i-cog">Management Controls</span>
</div>
<div class="mws-panel-body"><div class="mws-panel-content">
	<?php
		if( isset( $_GET['reset'] ) ) {
			$db->query( "DELETE FROM timetable WHERE perm != '1'" );
			echo "<div class=\"mws-form-message success\">Success!<ul><li>All timetable slots cleared.</li></ul></div>";
		}
		if( isset( $_GET['reset_week'] ) ) {
			$db->query( "DELETE FROM timetable WHERE perm != '1' AND day = '1'" );
			$db->query( "DELETE FROM timetable WHERE perm != '1' AND day = '2'" );
			$db->query( "DELETE FROM timetable WHERE perm != '1' AND day = '3'" );
			$db->query( "DELETE FROM timetable WHERE perm != '1' AND day = '4'" );
			$db->query( "DELETE FROM timetable WHERE perm != '1' AND day = '5'" );
			echo "<div class=\"mws-form-message success\">Success!<ul><li>Monday-Friday slots cleared.</li></ul></div>";
		}
		if( isset( $_GET['reset_weekend'] ) ) {
			$db->query( "DELETE FROM timetable WHERE perm != '1' AND day = '6'" );
			$db->query( "DELETE FROM timetable WHERE perm != '1' AND day = '7'" );
			echo "<div class=\"mws-form-message success\">Success!<ul><li>Saturday-Sunday slots cleared.</li></ul></div>";
		}
	?>
<div style="float: right;">
	<form action="?reset" method="post" onsubmit="return confirm('Are you sure you want to clear all slots?');">
		<input type="submit" class="mws-button red"" value="Clear Timetable" />
	</form>
</div>
<div style="float: right;">
	<form action="?reset_weekend" method="post" onsubmit="return confirm('Are you sure you want to clear Saturday-Sunday slots?');">
		<input type="submit" class="mws-button red"" value="Clear Saturday-Sunday" />
	</form>
</div>
<div style="float: right;">
	<form action="?reset_week" method="post" onsubmit="return confirm('Are you sure you want to clear Monday-Friday slots?');">
		<input type="submit" class="mws-button red"" value="Clear Monday-Friday" />
	</form>
</div>
<br clear="all"/>
</div></div>
</div>

<?php
	
	}
		
?>
            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-table-1">Radio Timetable // Please book all slots in GMT! - <I>(GMT time can be found at the top right of your screen!)</i></span>
                    </div>
                    <div class="mws-panel-body">
                        <table class="mws-table">

                            <thead>
                                <tr>
                                    <th style="text-align: center;" width="12.5%">Time</th>
                                    <th style="text-align: center;" width="12.5%" >Monday</th>
                                    <th style="text-align: center;" width="12.5%" >Tuesday</th>
                                    <th style="text-align: center;" width="12.5%" >Wednesday</th>
                                    <th style="text-align: center;" width="12.5%" >Thursday</th>
                                    <th style="text-align: center;" width="12.5%" >Friday</th>
                                    <th style="text-align: center;" width="12.5%" >Saturday</th>
                                    <th style="text-align: center;" width="12.5%" >Sunday</th>
                                </tr>
                            </thead>
                                <?php
                                for ($l = 0; $l <=23; $l++){
                                $k = $l + 1;
                                if( $l < 10 ) { 
                                $time = "0{$l}:00"; 
                                } 
                                else { 
                                    $time = "{$l}:00"; 
                                } 
                                if( $k < 10 ) { 
                                    $time2 = "0{$k}:00"; 
                                 } 
                                elseif( $k == 24 ) { 
                                    $time2 = "00:00"; 
                                } 
                                else { 
                                    $time2 = "{$k}:00"; 
                                } 
                                ?>
                                <tr class="gradeA">
                                    <td width="12.5%" style="text-align: center;">
                                       <?php echo "". $time . " - " . $time2 . ""; ?>
                                    </td>
                                    <?php
                                    for( $i = 1; $i <= 7; $i++ ) {
                                        
                                        $day = strtotime( "{$i} november 2010" );
                                        $day = date( "l", $day );
                                    ?>
                                    <td style="text-align: center;">
                                    <?php
                                        $query = $db->query ("SELECT * FROM timetable WHERE day = '{$i}' AND time = '{$l}' ");
                                        $array = $db->assoc( $query );
                                        $num   = $db->num( $query );

                                        $query2 = $db->query( "SELECT * FROM users WHERE id = '{$array['dj']}'" );
                                        $array2 = $db->assoc( $query2 );

                                        $query3 = $db->query( "SELECT * FROM usergroups WHERE id = '{$array2['displaygroup']}'" );
                                        $array3 = $db->assoc( $query3 );

                                        if( $num == 0 ) {

                                            echo "<a style=\"color: #323232; text-decoration: none; font-weight: bold;\" id=\"slot_{$i}_{$l}\" href=\"#\" onclick=\"Radi.bookSlot('{$i}','{$l}'); return false;\">";
                                            echo "Book";
                                            echo "</a>";
                                        
                                        }
                                        elseif( $array['dj'] == $user->data['id'] or $user->hasGroup( '4' ) or $user->hasGroup( '5' ) ) {
                                            
                                            echo "<a id=\"slot_{$i}_{$l}\" href=\"#\" onclick=\"Radi.bookSlot('{$i}','{$l}'); return false;\" style=\"text-decoration: none; font-weight: bold; color: #{$array3['colour']}\">";
                                            echo $array2['username'];
                                            echo "</a>";
                                        
                                        } else {
                                            
                                            echo "<span style=\"color: #{$array3['colour']}; font-weight: bold;\">";
                                            echo $array2['username'];
                                            echo "</span>";
                                            
                                    }
                                    ?>
                                </td>
                                <?php } ?>
                                </tr>
                                <?php } ?>
                            <tbody>



                            </tbody>
                        </table>
                    </div>
                </div>