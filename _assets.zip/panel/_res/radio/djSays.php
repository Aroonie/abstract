<?php
	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }
        $date  = date("l jS \of F Y h:i:s A");
        $ipAddress = $_SERVER['REMOTE_ADDR'];

?>

            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-home">DJ Says</span>
                    </div>
                    <div class="mws-panel-body">
                    	<form action="" method="post" id="djSays" class="mws-form">
		<?php

			if( $_POST['submit'] ) {

				try {

					$message = $core->clean( $_POST['djsays'] );

					if( !$message ) {

						throw new Exception( "All fields are required." );

					}
					else {
						
						$ip = $_SERVER['REMOTE_ADDR'];
						
						$db->query( "INSERT INTO dj_says VALUES (NULL, '{$message}', '{$user->data['id']}', '{$ip}');" );
						$db->query( "INSERT INTO logs VALUES (NULL, '{$user->data['username']}', '{$ipAddress}', '{$date}', 'Successfully changed the DJ Says')" );
						echo "<div class=\"mws-form-message success\">Success!<ul><li>DJ says successfully updated!</li></ul></div>";

					}

				}
				catch( Exception $e ) {

					echo "<div class=\"mws-form-message error\">";
					echo "Error";
					echo "<ul><li>";
					echo $e->getMessage();
					echo "</li></ul></div>";

				}

			}

		?>
                    		<div class="mws-form-inline">
                    			<div class="mws-form-row">
                    				<label>Current DJ Says</label>
                    				<div class="mws-form-item medium">
			<?php

				$query = $db->query( "SELECT * FROM dj_says ORDER BY id DESC" );
				$array = $db->assoc( $query );
	
				$djSays = $array['message'];

				echo "<input type=\"text\" class=\"mws-textinput\" id=\"djsays\" value=\"$djSays\" readonly />";

			?>
                    				</div>
                    			</div>
                    			<div class="mws-form-row">
                    				<label>New DJ Says</label>
                    				<div class="mws-form-item medium">
                    						<input type="text" class="mws-textinput" id="djsays" name="djsays" />
                    				</div>
                    			</div>
                    		</div>
                    		<div class="mws-button-row">
                    			<input type="submit" name="submit" value="Submit" class="mws-button red" />
                    			<input type="reset" value="Reset" class="mws-button gray" />
                    		</div>
                    	</form>
                    </div>    	
                </div>
<?php
echo $core->buildFormJS('djSays');
?>