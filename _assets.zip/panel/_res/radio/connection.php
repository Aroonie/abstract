<?php
	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }
        $date  = date("l jS \of F Y h:i:s A");
        $ipAddress = $_SERVER['REMOTE_ADDR'];
	$query = $db->query( "SELECT * FROM connection_info ORDER BY id DESC LIMIT 1" );
	$array = $db->assoc( $query );
        $check = $db->query("SELECT * FROM users WHERE id = '{$user->data['id']}'");
        $checkarray = $db->assoc($check);
?>
<?php
if ($checkarray['viewed_info'] == '1') {
?>
<div class="mws-panel grid_8">
   <div class="mws-panel-header">
      <span class="mws-i-24 i-cog">Connection Information</span>
   </div>
   <div class="mws-panel-body">
      <div class="mws-panel-content">
<?php
$db->query( "INSERT INTO logs VALUES (NULL, '{$user->data['username']}', '{$ipAddress}', '{$date}', 'Failed to view connection information')" );
?>
It seems that you've already viewed the connection information. Please contact a head dj or your manager.
      </div>
   </div>
</div>
<?php
} else {
?>
<div class="mws-panel grid_8">
   <div class="mws-panel-header">
      <span class="mws-i-24 i-cog">Connection Information</span>
   </div>
   <div class="mws-panel-body">
      <div class="mws-panel-content">
<?php
$db->query( "INSERT INTO logs VALUES (NULL, '{$user->data['username']}', '{$ipAddress}', '{$date}', 'Successfully viewed connection information')" );
$db->query("UPDATE users SET viewed_info = '1' WHERE id = '{$user->data['id']}'");
?>
	<strong>Station Name:</strong><br />
	<?php echo $user->data['username']; ?>
	<br /><br />
	<strong>Genre:</strong><br />
	<?php echo $user->data['habbo']; ?>
	<br /><br />
	<strong>Quality:</strong><br />
	High Quality
	<br /><br />
	<strong>Bitrate/Format:</strong><br />
	128 Kb/s, 44.1 kHz Stereo
	<br /><br />
	<strong>Connection IP:</strong><br />
	<?php echo $array['host']; ?>
	<br /><br />
	<strong>Connection port:</strong><br />
	<?php echo $array['port']; ?>
	<br /><br />
	<strong>Connection password:</strong><br />
	<?php echo $array['password']; ?> <I>(This is changed Monthly or whenever a member of staff is fired!)</i>

      </div>
   </div>
</div>
<?php
}
?>