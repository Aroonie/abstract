<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

?>

            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-table-1">My Warnings</span>
                    </div>
                    <div class="mws-panel-body">
                        <table class="mws-table">
                            <thead>
                                <tr>
                                    <th>DJ</th>
                                    <th>Reason</th>
                                    <th>Read (0 = No, 1 = Yes)</th>
                                </tr>
                            </thead>
                            <tbody>
	<?php

                $query = $db->query( "SELECT * FROM warnings WHERE dj = '{$user->data['id']}' ORDER BY id DESC" );
		$num   = $db->num( $query );

		$j = "a";

		while( $array = $db->assoc( $query ) ) {
                $query2 = $db->query( "SELECT * FROM users WHERE id = '{$array['dj']}'" );
		$array2 = $db->assoc( $query2 );

			echo "<tr class=\"row {$j}\" id=\"news_{$array['id']}\">";

			echo "<td>" . $array2['username'] . "</td>";
			echo "<td>" . $array['type'] . "</td>";
			echo "<td>" . $array['is_read'] . "</td>";

			echo "<tr>";

			$j++;

			if( $j == "c" ) {

				$j = "a";

			}

		}

		if( $num == 0 ) {

			echo "<div class=\"square good\" align=\"left\">";
			echo "<strong>Success</strong>";
			echo "<br />";
			echo "You have no warnings! Well done!";
			echo "</div>";

		}

	?>
                            </tbody>
                        </table>
                    </div>
                </div>
<?php
$db->query( "UPDATE warnings SET is_read = '1' WHERE dj = '{$user->data['id']}'" );
?>