<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

?>

                <div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-headphones">Latest Played Songs</span>
                    </div>
                    <div class="mws-panel-body">
                    	<div class="mws-panel-content">
<div class="box">

	<div class="square title" style="background-color: #<?php echo $arrayColor[colour]; ?> !important;">
		<strong>Recently Played Songs</strong>
	</div>

	<div class="content">
<div id="cc_recenttracks_madhabbo" class="cc_recenttracks_list">Loading ...</div>

	</div>

</div>
<script language="javascript" type="text/javascript" src="http://sc.madhabbo.com:2199/system/recenttracks.js"></script>
</div>
                    </div>
                </div>