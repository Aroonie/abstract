<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

?>
            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-table-1">Manage News</span>
                    </div>
                    <div class="mws-panel-body">
                        <table class="mws-table">
                            <thead>
                                <tr>
                                    <th>Article Name</th>
                                    <th>Posted By</th>
                                    <th>Date Posted</th>
                                    <th>Controls</th>
                                </tr>
                            </thead>
                            <tbody>
	<?php

                $query = $db->query( "SELECT * FROM news ORDER BY id DESC" );
		$num   = $db->num( $query );

		$j = "a";

		while( $array = $db->assoc( $query ) ) {
                $query2 = $db->query("SELECT * FROM users WHERE id = '{$array['author']}'");
                $array2 = $db->assoc($query2);

			echo "<tr class=\"row {$j}\" id=\"news_{$array['id']}\">";

			echo "<td>" . $array['title'] . "</td>";
			echo "<td>" . $array2['username'] . "</td>";
			echo "<td>";
			echo "" . date("d.m.Y", $array['stamp']) . "";
			echo "</td>";
			echo "<td><center>";
			echo "<a href=\"news.add?id={$array['id']}\">";
			echo "<img src=\"_img/pencil.png\" alt=\"Edit\" />";
			echo "</a>";

			echo "<a href=\"#\" onclick=\"Radi.deleteNews('{$array['id']}');\">";
			echo "<img src=\"_img/minus.png\" alt=\"Delete\" />";
			echo "</a>";

			echo "</center></td>";

			echo "<tr>";

			$j++;

			if( $j == "c" ) {

				$j = "a";

			}

		}

		if( $num == 0 ) {

			echo "<div class=\"square bad\" style=\"margin-bottom: 0px;\">";
			echo "<strong>Sorry</strong>";
			echo "<br />";
			echo "There is no news...";
			echo "</div>";

		}

	?>
                            </tbody>
                        </table>
                    </div>
                </div>