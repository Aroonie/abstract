<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

	if( $_GET['id'] ) {
		
		$id = $core->clean( $_GET['id'] );
		
		$query = $db->query( "SELECT * FROM news WHERE id = '{$id}'" );
		$data  = $db->assoc( $query );
		
		$editid = $data['id'];
		
	}

?>
            	<div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-home">Add News</span>
                    </div>
                    <div class="mws-panel-body">
                    	<form action="" method="post" id="addNews" class="mws-form">
                    		<div class="mws-form-inline">
		<?php

			if( $_POST['submit'] ) {

				try {
					
					$title   = $core->clean( $_POST['title'] );
					$desc    = $core->clean( $_POST['desc'] );
					$cat     = $core->clean( $_POST['cat'] );
					$article = $core->clean( $_POST['article'] );
					$time    = time();

					if( !$title or !$desc or !$cat or !$article ) {

						throw new Exception( "All fields are required." );

					}
					else {
						
						if( $editid ) {
							
							$db->query( "UPDATE news SET title = '{$title}', `desc` = '{$desc}', category = '{$cat}', article = '{$article}' WHERE id = '{$editid}'");
							
						}
						else {
						
							$db->query( "INSERT INTO news VALUES (NULL, '{$cat}', '{$title}', '{$desc}', '{$article}', '{$user->data['id']}', '{$time}');" );
						
						}

						echo "<div class=\"mws-form-message success\">Success!<ul><li>Article successfully added!</li></ul></div>";

					}

				}
				catch( Exception $e ) {

					echo "<div class=\"mws-form-message error\">";
					echo "Error";
					echo "<ul><li>";
					echo $e->getMessage();
					echo "</li></ul></div>";

				}

			}

		?>

			<?php

				$query = $db->query( "SELECT * FROM news_categories" );
				
				while( $array = $db->assoc( $query ) ) {
					
					if( $array['admin'] != '1' or ( $user->hasGroup( '4' ) or $user->hasGroup( '5' ) ) ) {
					
						if( $array['id'] == $data['category'] ) {
						
							$cats[$array['id'] . "_active"] = $array['name'];
							
						}
						else {
						
							$cats[$array['id']] = $array['name'];
						
						}
					
					}
					
				}

				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Article Title</label>";
				echo "<div class=\"mws-form-item clearfix\">";
				echo $core->buildField( "text",
										"required",
										"title",
										"",
										"Your article's name.",
										$data['title'] );
				echo "</div></div>";

				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Description</label>";
				echo "<div class=\"mws-form-item clearfix\">";
				echo $core->buildField( "text",
										"required",
										"desc",
										"",
										"A short description of your article.",
										$data['desc'] );
				echo "</div></div>";

				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Category</label>";
				echo "<div class=\"mws-form-item clearfix\">";
				echo $core->buildField( "select",
										"required",
										"cat",
										"",
										"Your article's category.",
										$cats );
				echo "</div></div>";

				echo "<div class=\"mws-form-row\">";
                    		echo "<label>Article</label>";
				echo "<div class=\"mws-form-item clearfix\">";
				echo $core->buildField( "big_textarea",
										"required",
										"article",
										"",
										"Your article for the site.",
										$data['article'] );
				echo "</div></div>";

			?>
                    		</div>
                    		<div class="mws-button-row">
                    			<input type="submit" name="submit" value="Submit" class="mws-button red" />
                    			<input type="reset" value="Reset" class="mws-button gray" />
                    		</div>
                    	</form>
                    </div>    	
                </div>

<?php
	echo $core->buildFormJS('addNews');
?>