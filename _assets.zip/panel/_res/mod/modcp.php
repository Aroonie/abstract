<?php

	if( !preg_match( "/index.php/i", $_SERVER['PHP_SELF'] ) ) { die(); }

?>
<style type="text/css">
	a {
		text-decoration: none;
		color: black;
	}
</style>
                <div class="mws-panel grid_8">
                	<div class="mws-panel-header">
                    	<span class="mws-i-24 i-alert">Mod CP Login</span>
                    </div>
                    <div class="mws-panel-body">
                    	<div class="mws-panel-content">
<div class="box">
	</div>

	<div class="content">

<strong>Username: </strong>modCP<br />
<strong>Password: </strong>uPkzh6a$w%9$c]$JdQ<br />
<strong>Link: </strong><a href="http://www.madhabboforum.com/area52" target="_blank">Moderator CP</a>




	</div>

</div>
</div>
                    </div>
                </div>