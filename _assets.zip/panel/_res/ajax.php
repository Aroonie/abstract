<?php
	require_once("../_inc/glob.php");
	
	if( !$user->loggedIn ) { die(); }
	
	if( $_POST['mode'] == "requestsByType" and $_POST['id'] ) {
		
		$id = $core->clean( $_POST['id'] );
		
		if( $id == "*" ) {
		
			$query2 = $db->query( "SELECT * FROM requests WHERE `for` = '{$user->data['id']}'" );
		
		}
		elseif( $id == "all" and ( $user->hasGroup( '4' ) or $user->hasGroup( '5' ) ) ) {
		
			$query2 = $db->query( "SELECT * FROM requests" );
		
		}
		else {
		
			$query2 = $db->query( "SELECT * FROM requests WHERE type = '{$id}' AND `for` = '{$user->data['id']}'" );
		
		}
		
		$num2 = $db->num( $query2 );
		
		while( $array2 = $db->assoc( $query2 ) ) {
		
			$query = $db->query( "SELECT * FROM request_types WHERE id = '{$array2['type']}'" );
			$array = $db->assoc( $query );
			
			$query3 = $db->query( "SELECT * FROM users WHERE id = '{$array2['for']}'" );
			$array3 = $db->assoc( $query3 );
			
			$array2['for'] = $array3['username'];
			
			$array2['type'] = "<span style=\"color: #{$array['colour']}; font-size: 14px;\">" . $array['name'] . "</span>";
		
?>

<div class="box" id="request_<?php echo $array2['id']; ?>">
	
	<div class="square title" id="header_<?php echo $array2['id']; ?>" style="margin-bottom: 0px;">
	
		<div style="float: left; width: 70%;">
	
			<strong>Entry from <?php echo $array2['author']; ?> for <?php echo $array2['for']; ?></strong>
	
		</div>

		<div style="float: right; width: 30%; text-align: right;">
			
			<?php echo $array2['type']; ?>

			&nbsp;

			<a href="#" onclick="Radi.requestToggle('<?php echo $array2['id']; ?>'); return false;">
	
				<img src="_img/request_check.png" alt="Toggle delete" align="right" id="delcheck_<?php echo $array2['id']; ?>" />
	
			</a>
	
		</div>

		<br clear="all" />

	</div>

	<div style="padding: 5px;">
	
		<div>
	
			<?php echo $array2['message']; ?>
	
		</div>

		<div style="font-size: 11px; margin-top: 3px; border-top: 1px #eee solid;">

			<a href="#" onclick="Radi.deleteRequest(<?php echo $array2['id']; ?>); return false;"><img src="_img/minus.png" alt="Delete" align="right" style="position: relative; top: 2px;" /></a>

			<?php echo date( "d/m/Y H:i", $array2['stamp'] ); ?>
			(<?php echo $array2['ip']; ?>)

		</div>
	
	</div>

</div>

<?php
			
		}

		if( $num2 == 0 ) {
			
			echo "<div class=\"box\">";
			
			echo "<div class=\"square bad\" style=\"margin-bottom: 0px;\">";
			echo "<strong>Sorry</strong>";
			echo "<br />";
			echo "There are no requests in this category.";
			echo "</div>";
			
			echo "</div>";
			
		}

	}
	elseif( $_POST['mode'] == "deleteRequest" and $_POST['id'] ) {
		
		$id = $core->clean( $_POST['id'] );
		
		$query = $db->query( "SELECT * FROM requests WHERE `for` = '{$user->data['id']}' AND id = '{$id}'" );
		$num   = $db->num( $query );
		
		if( $num != 0 ) {
			
			$db->query( "DELETE FROM requests WHERE id = '{$id}'" );
			
		}
		
	}
	elseif( $_POST['mode'] == "deleteNews" and $_POST['id'] ) {

		$id = $core->clean( $_POST['id'] );

		$query = $db->query( "SELECT * FROM news WHERE id = '{$id}'" );
		$array = $db->assoc( $query );

		if( $array['author'] == $user->data['id'] or ( $user->hasGroup( '4' ) or $user->hasGroup( '5' ) ) ) {

			$db->query( "DELETE FROM news WHERE id = '{$id}'" );

		}

	}
	elseif( $_POST['mode'] == "deleteNewsCat" and $_POST['id'] ) {

		$id = $core->clean( $_POST['id'] );

		if( $user->hasGroup( '4' ) ) {

			$db->query( "DELETE FROM news_categories WHERE id = '{$id}'" );

		}

	}
	elseif( $_POST['mode'] == "deleteReviews" and $_POST['id'] ) {

		$id = $core->clean( $_POST['id'] );

		if( $user->hasGroup( '4' ) ) {

			$db->query( "DELETE FROM djreviews WHERE id = '{$id}'" );

		}

	}
	elseif( $_POST['mode'] == "deleteJobApps" and $_POST['id'] ) {

		$id = $core->clean( $_POST['id'] );

		if( $user->hasGroup( '4' ) ) {

			$db->query( "DELETE FROM jobapps WHERE id = '{$id}'" );

		}

	}
	elseif( $_POST['mode'] == "deleteContactUs" and $_POST['id'] ) {

		$id = $core->clean( $_POST['id'] );

		if( $user->hasGroup( '4' ) ) {

			$db->query( "DELETE FROM contactus WHERE id = '{$id}'" );

		}

	}
	elseif( $_POST['mode'] == "deleteLogs" and $_POST['id'] ) {

		$id = $core->clean( $_POST['id'] );

		if( $user->hasGroup( '4' ) ) {

			$db->query( "DELETE FROM logs WHERE id = '{$id}'" );

		}

	}
	elseif( $_POST['mode'] == "deleteUser" and $_POST['id'] ) {

		$id = $core->clean( $_POST['id'] );
		$data1 = $db->query( "SELECT * FROM users WHERE id = '{$id}'" );
		$data = $db->assoc( $data1 );
		
		$date  = date("l jS \of F Y h:i:s A");
        	$ipAddress = $_SERVER['REMOTE_ADDR'];

		if( $user->hasGroup( '4' ) AND !$user->hasGroup( '5' ) ) {

                        if ($data['displaygroup'] == "4" || $data['displaygroup'] == "5"){

                        	// Fail!

			} else {

                        	$db->query( "DELETE FROM users WHERE id = '{$id}'" );
                        	$db->query( "DELETE FROM timetable WHERE dj = '{$id}'" );
				$db->query( "INSERT INTO logs VALUES (NULL, '{$user->data['username']}', '{$ipAddress}', '{$date}', 'Deleted {$data['username']} from the panel')" );
    
			}

		  }else {

			$db->query( "DELETE FROM users WHERE id = '{$id}'" );
			$db->query( "DELETE FROM timetable WHERE dj = '{$id}'" );
			$db->query( "INSERT INTO logs VALUES (NULL, '{$user->data['username']}', '{$ipAddress}', '{$date}', 'Deleted {$data['username']} from the panel')" );

		  }
	}
	elseif( $_POST['mode'] == "deleteUser2" and $_POST['id']) {

		$id = $core->clean( $_POST['id'] );
		$data1 = $db->query( "SELECT * FROM users WHERE id = '{$id}'" );
		$data = $db->assoc( $data1 );
		
		$date  = date("l jS \of F Y h:i:s A");
        	$ipAddress = $_SERVER['REMOTE_ADDR'];
                $username = $user->data['username'];

		if( $user->hasGroup( '4' ) AND !$user->hasGroup( '5' ) ) {

                        if ($data['displaygroup'] == "4" || $data['displaygroup'] == "5"){

                        	// Fail!

			} else {

                     $db->query( "UPDATE users SET deleteid = '1', deleteuser = '{$user->data['username']}' WHERE id = '{$id}'" );
	$db->query( "INSERT INTO logs VALUES (NULL, '{$user->data['username']}', '{$ipAddress}', '{$date}', 'Deleted {$data['username']}, they are now pending delete.')" );
    
			}

		  }else {

			$db->query( "UPDATE users SET deleteid = '1', deleteuser = '{$user->data['username']}' WHERE id = '{$id}'" );
			$db->query( "INSERT INTO logs VALUES (NULL, '{$user->data['username']}', '{$ipAddress}', '{$date}', 'Deleted {$data['username']}, they are now pending delete.')" );

		  }

	}
	elseif( $_POST['mode'] == "deleteMenuItem" and $_POST['id'] ) {

		$id = $core->clean( $_POST['id'] );

		if( $user->hasGroup( '5' ) ) {

			$db->query( "DELETE FROM menu WHERE id = '{$id}'" );

		}

	}
	elseif( $_POST['mode'] == "deleteUsergroup" and $_POST['id'] ) {

		$id = $core->clean( $_POST['id'] );

		if( $user->hasGroup( '5' ) ) {

			$db->query( "DELETE FROM usergroups WHERE id = '{$id}'" );

		}
	}
	elseif( $_POST['mode'] == "deleteRequestType" and $_POST['id'] ) {

		$id = $core->clean( $_POST['id'] );

		if( $user->hasGroup( '4' ) ) {

			$db->query( "DELETE FROM request_types WHERE id = '{$id}'" );

		}

	}
	elseif( $_POST['mode'] == "deletePermShow" and $_POST['id'] ) {

		$id = $core->clean( $_POST['id'] );

		if( $user->hasGroup( '4' ) ) {

			$db->query( "DELETE FROM timetable WHERE id = '{$id}'" );

		}

	}
	elseif( $_POST['mode'] == "deleteEvent" and $_POST['id'] ) {

		$id = $core->clean( $_POST['id'] );

		if( $user->hasGroup( '4' ) ) {

			$db->query( "DELETE FROM events WHERE id = '{$id}'" );

		}

	}
	elseif( $_POST['mode'] == "deleteCheckedRequests" and $_POST['list'] ) {
		
		$list = explode( ",", $core->clean( $_POST['list'] ) );
		
		foreach( $list as $key => $value ) {
		
			$id = $core->clean( $value );
	
			$query = $db->query( "SELECT * FROM requests WHERE `for` = '{$user->data['id']}' AND id = '{$id}'" );
			$num   = $db->num( $query );
	
			if( $num != 0 ) {
	
				$db->query( "DELETE FROM requests WHERE id = '{$id}'");
	
			}
			
		}
		
	}
	elseif( $_POST['mode'] == "bookSlot" and $_POST['day'] != "" and $_POST['time'] != "" ) {
		
		$day  = $core->clean( $_POST['day'] );
		$time = $core->clean( $_POST['time'] );
		
		$query = $db->query( "SELECT * FROM timetable WHERE day = '{$day}' AND time = '{$time}' ");
		$array = $db->assoc( $query );
		$num   = $db->num( $query );
		
		if( $num == 1 and ($array['dj'] == $user->data['id'] or $user->hasGroup( '4' ) or $user->hasGroup( '5' ) ) ) {
			
			$db->query( "DELETE FROM timetable WHERE day = '{$day}' AND time = '{$time}'");
			
			echo "Book";
			echo "@-";
			echo "inherit";
			
		}
		elseif( $num == 0 ) {
			
			$db->query( "INSERT INTO timetable VALUES (NULL, '{$day}', '{$time}', '{$user->data['id']}', '0');" );
			
			echo $user->data['username'];
			echo "@-";
			echo "#" . $user->data['usergroup']['colour'];
		
		}
		
	}
?>