<?php
	error_reporting(0);
	$params['db']['hostname']  = "localhost";
	$params['db']['username']  = "weareabs_staff";
	$params['db']['password']  = "Ps193300?";
	$params['db']['database']  = "weareabs_stafftest";

	require_once( "db.inc.php" );
	require_once( "core.inc.php" );
?>