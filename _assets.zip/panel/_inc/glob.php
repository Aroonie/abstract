<?php
	##############
	## glob.php ##
	##############

date_default_timezone_set('Etc/GMT+0');

	$params['db']['hostname']  = "localhost";
	$params['db']['username']  = "weareabs_staff";
	$params['db']['password']  = "Ps193300?";
	$params['db']['database']  = "weareabs_stafftest";

	$params['core']['salt1']   = "4730b178f6";
	$params['core']['salt2']   = "59999a713e";

	$params['user']['timeout'] = "120 minutes";

	session_start();
	putenv( "TZ=Europe/London" );

	require_once( "db.inc.php" );
	require_once( "core.inc.php" );
	require_once( "user.inc.php" );
	
?>