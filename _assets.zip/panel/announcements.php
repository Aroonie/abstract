<?php

	require_once( "_inc/glob.php" );

?>

<?php
$query = $db->query( "SELECT * FROM announcement" );
while( $array = $db->assoc( $query ) ) {

$result = $array['message'];

  echo "<div class=\"result\">" . htmlspecialchars_decode($result) . "</div>";
  echo "<br />";

  }

?>

</body>
</html>