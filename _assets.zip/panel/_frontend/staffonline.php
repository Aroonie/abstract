<?php
	require_once( "../_inc/glob.php" );
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

	<head>

		<title>radiPanel Staff Online</title>

		<style type="text/css" media="screen">

			body {
				background:;
				padding: 0;
				margin: 0;

			}

			body, input, select, textarea {

				font-family: Verdana, Tahoma, Arial;
				font-size: 11px;
				color: #333;

			}

			form {

				padding: 0;
				margin: 0;

			}

			.wrapper {

				background-color:;
				width: 300px;
				margin: auto;
				padding: 5px;
				margin-top: 15px;

			}

			.title {

				padding: 5px;	
				margin-bottom: 5px;
				font-size: 14px;
				font-weight: bold;
				background-color:;
				color: #444;

			}

			.content {

				padding: 5px;

			}

			.good, .bad {

				padding: 5px;	
				margin-bottom: 5px;

			}

			.good strong, .bad strong {

				font-size: 14px;
				font-weight: bold;

			}

			.good {

				background-color: #d9ffcf;
				border-color: #ade5a3;
				color: #1b801b;

			}

			.bad {

				background-color: #ffcfcf;
				border-color: #e5a3a3;
				color: #801b1b;

			}

			input, select, textarea {

				border: 1px #e0e0e0 solid;
				border-bottom-width: 2px;
				padding: 3px;

			}

			input {

				width: 170px;

			}

			input.button {

				width: auto;
				cursor: pointer;
				background: #eee;

			}

			select {

				width: 176px;

			}

			textarea {

				width: 288px;

			}

			label {

				display: block;
				padding: 3px;

			}

		</style>
		<body>
		<div class="wrapper">
			<div class="content" align="center">
			
					<?php 
	
					$query = $db->query( "SELECT DISTINCT user_id FROM sessions WHERE user_id != '0'" ); 
    					$i = 1; 

					while( $array = $db->assoc( $query ) ) { 

						$queryU = $db->query( "SELECT * FROM users WHERE id = '{$array['user_id']}'" ); 
						$arrayU = $db->assoc( $queryU ); 

						$queryUG = $db->query( "SELECT * FROM usergroups WHERE id = '{$arrayU['displaygroup']}'" ); 
						$arrayUG = $db->assoc( $queryUG ); 

						echo "<span style=\"color: #{$arrayUG['colour']}; font-weight: bold;\">"; 
						echo $arrayU['username']; 
						echo "</span>"; 
						echo ( $i == $db->num( $query ) ) ? '' : ', '; 

						$i++; 

					} 

					?>
					</div>
</body>

</html>