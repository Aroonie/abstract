<?php
        require_once( "../_inc/glob.php" );
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
 
        <head>
       
        <!-- Coded by CCQ from Habbo.com -->
        <!-- Want anymore addon's add me on msn Kyle@Blader.com and tell me what your after and i'll see what i can code into RadiPanel for you. -->
        <!-- Enjoy -->
 
                <title>radiPanel Staff</title>
 
                <style type="text/css" media="screen">
 
                       
                       
                       
 
                        
 
                        .wrapper {
 
                                background-color: #fcfcfc;
                                width: 400px;
                                margin: auto;
                                padding: 5px;
                                margin-top: 15px;
                                height: auto;
                                overflow: hidden;
 
                        }
 
                        .title {
 
                                padding: 5px;  
                                margin-bottom: 5px;
                                font-size: 14px;
                                font-weight: bold;
                                background-color: #eee;
                                color: #444;
 
                        }
 
                        .good, .bad {
                       
                                padding: 5px;  
                                margin-bottom: 5px;
                       
                        }
                       
                        .good strong, .bad strong {
                       
                                font-size: 12px;
                                font-weight: bold;
                       
                        }
                       
                        .good {
       
                                background-color: #d9ffcf;
                                border-color: #ade5a3;
                                color: #1b801b;
       
                        }
       
                        .bad {
 
       
                                background-color: #ffcfcf;
                                border-color: #e5a3a3;
                                color: #801b1b;
       
                        }
 
                        input, select, textarea {
 
                                border: 1px #e0e0e0 solid;
                                border-bottom-width: 2px;
                                padding: 3px;
 
                        }
 
                        input {
               
                                width: 170px;
               
                        }
                       
                        input.button {
                       
                                width: auto;
                                cursor: pointer;
                                background: #eee;
                       
                        }
                       
                        select {
                       
                                width: 176px;
                       
                        }
                       
                        textarea {
                       
                                width: 288px;
                       
                        }
                       
                        label {
                       
                                display: block;
                                padding: 3px;
                       
                        }
                       
                        .staff {
                       
                                width: 130px;
                                height: auto;
                                overflow: hidden;
                                float: left;
               
                        }
                       
                </style>
 
        </head>
 
<body>
 
<div class="wrapper">
 
        <div class="title">
        Administrator
        </div>
       
        <?php
        $query = $db->query( "SELECT username,displaygroup,habbo,email FROM users WHERE displaygroup = 5 ORDER BY displaygroup DESC" );
        $num = $db->num($query);
        while( $array = $db->assoc( $query ) ) {
       
        $id = $array['id'];
        if( $array['displaygroup'] == "5" ) {
        $displaygroup = "<strong>Administrator</strong>";
        }
        echo "
        <div class=\"staff\" align=\"center\">
        <img src=\"http://www.habbo.com/habbo-imaging/avatarimage?user=".$array['habbo']."&action=0&direction=4&head_direction=3&gesture=0&size=s\" border=\"0\"><br />
        <strong><a href=\"http://www.habbo.com/home/".$array['habbo']."\" target=\"_blank\">".$array['habbo']."</a></strong>
        </div>
        ";
        }
        if($num == 0 ) {
        echo "<div class=\"bad\">There's currently no user's in this user group.</div>";
        }
        ?>
 
</div>
 
<div class="wrapper">
 
        <div class="title">
        Management
        </div>
       
        <?php
        $query = $db->query( "SELECT username,displaygroup,habbo,email FROM users WHERE displaygroup = 4 ORDER BY displaygroup DESC" );
        $num = $db->num($query);
        while( $array = $db->assoc( $query ) ) {
       
        echo "
        <div class=\"staff\" align=\"center\">
        <img src=\"http://www.habbo.com/habbo-imaging/avatarimage?user=".$array['habbo']."&action=0&direction=4&head_direction=3&gesture=0&size=s\" border=\"0\"><br />
        <strong><a href=\"http://www.habbo.com/home/".$array['habbo']."\" target=\"_blank\">".$array['habbo']."</a></strong>
        </div>
        ";
        }
        if($num == 0 ) {
        echo "<div class=\"bad\">There's currently no user's in this user group.</div>";
        }
        ?>
 
</div>
 
<div class="wrapper">
 
        <div class="title">
        News Team
        </div>
       
        <?php
        $query = $db->query( "SELECT username,displaygroup,habbo,email FROM users WHERE displaygroup = 3 ORDER BY displaygroup DESC" );
        $num = $db->num($query);
        while( $array = $db->assoc( $query ) ) {
       
        echo "
        <div class=\"staff\" align=\"center\">
        <img src=\"http://www.habbo.com/habbo-imaging/avatarimage?user=".$array['habbo']."&action=0&direction=4&head_direction=3&gesture=0&size=s\" border=\"0\"><br />
        <strong><a href=\"http://www.habbo.com/home/".$array['habbo']."\" target=\"_blank\">".$array['habbo']."</a></strong>
        </div>
        ";
        }
        if($num == 0 ) {
        echo "<div class=\"bad\">There's currently no user's in this user group.</div>";
        }
        ?>
 
</div>
 
<div class="wrapper">
 
        <div class="title">
        Radio DJs
        </div>
       
        <?php
        $query = $db->query( "SELECT username,displaygroup,habbo,email FROM users WHERE displaygroup = 2 ORDER BY displaygroup DESC" );
        $num = $db->num($query);
        while( $array = $db->assoc( $query ) ) {
       
        echo "
        <div class=\"staff\" align=\"center\">
        <img src=\"http://www.habbo.com/habbo-imaging/avatarimage?user=".$array['habbo']."&action=0&direction=4&head_direction=3&gesture=0&size=s\" border=\"0\"><br />
        <strong><a href=\"http://www.habbo.com/home/".$array['habbo']."\" target=\"_blank\">".$array['habbo']."</a></strong><br />
        DJ <strong>".$array['username']."</strong>
        </div>
        ";
        }
        if($num == 0 ) {
        echo "<div class=\"bad\">There's currently no user's in this user group.</div>";
        }
        ?>
 
</div>
 
</body>
 