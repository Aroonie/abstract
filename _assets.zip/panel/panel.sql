
/*
Navicat MySQL Data Transfer

Source Server         : WebServer
Source Server Version : 50547
Source Host           : localhost
Source Database       : weareabs_stafftest

Target Server Type    : MYSQL
Target Server Version : 50547
File Encoding         : 65001

Date: 2016-04-01 15:40:08
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `announcement`
-- ----------------------------
DROP TABLE IF EXISTS `announcement`;
CREATE TABLE `announcement` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `message` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of announcement
-- ----------------------------
INSERT INTO `announcement` VALUES ('1', 'Welcome to Version One!');

-- ----------------------------
-- Table structure for `connection_info`
-- ----------------------------
DROP TABLE IF EXISTS `connection_info`;
CREATE TABLE `connection_info` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `host` text NOT NULL,
  `port` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of connection_info
-- ----------------------------
INSERT INTO `connection_info` VALUES ('1', 'sc.madhabbo.com', '8880', 'VXxZYWIrEqAzRqd', '1', 'Hidden Fuck DICKS!');
INSERT INTO `connection_info` VALUES ('2', 'sc.madhabbo.com', '8880', 'VXxZYWIrEqAzRqd', '1', 'HIDDEN');
INSERT INTO `connection_info` VALUES ('3', 'sc.madhabbo.com', '8080', 'VXxZYWIrEqAzRqd', '2', '162.158.1.77');
INSERT INTO `connection_info` VALUES ('4', 'sc.madhabbo.com', '8080', 'p4FYrZ2oCNKcFj', '2', '162.158.1.77');

-- ----------------------------
-- Table structure for `connection_info_logs`
-- ----------------------------
DROP TABLE IF EXISTS `connection_info_logs`;
CREATE TABLE `connection_info_logs` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `result` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of connection_info_logs
-- ----------------------------

-- ----------------------------
-- Table structure for `contactus`
-- ----------------------------
DROP TABLE IF EXISTS `contactus`;
CREATE TABLE `contactus` (
  `id` int(11) NOT NULL,
  `habbo` int(11) NOT NULL,
  `contact` int(11) NOT NULL,
  `ip` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of contactus
-- ----------------------------

-- ----------------------------
-- Table structure for `current_event`
-- ----------------------------
DROP TABLE IF EXISTS `current_event`;
CREATE TABLE `current_event` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `roomid` int(255) NOT NULL,
  `uid` int(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of current_event
-- ----------------------------

-- ----------------------------
-- Table structure for `dj_says`
-- ----------------------------
DROP TABLE IF EXISTS `dj_says`;
CREATE TABLE `dj_says` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `author` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of dj_says
-- ----------------------------

-- ----------------------------
-- Table structure for `djreviews`
-- ----------------------------
DROP TABLE IF EXISTS `djreviews`;
CREATE TABLE `djreviews` (
  `id` int(11) NOT NULL,
  `habbo` int(11) NOT NULL,
  `review` int(11) NOT NULL,
  `username` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of djreviews
-- ----------------------------

-- ----------------------------
-- Table structure for `donators`
-- ----------------------------
DROP TABLE IF EXISTS `donators`;
CREATE TABLE `donators` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `habboname` varchar(255) NOT NULL,
  `habboimg` varchar(255) NOT NULL,
  `reason` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of donators
-- ----------------------------
INSERT INTO `donators` VALUES ('2', 'Andings', 'http://www.habbo.com/habbo-imaging/avatarimage?user=Andings&amp;action=std&amp;direction=4&amp;head_direction=3&amp;gesture=sml&amp;size=s&amp;actio', 'Web Servers, VBulletin License etc');
INSERT INTO `donators` VALUES ('1', '!!Undead!!', 'http://www.habbo.com/habbo-imaging/avatarimage?user=!!Undead!!&action=std&direction=4&head_direction=3&gesture=sml&size=s&actio', 'Everything that he had for the events');
INSERT INTO `donators` VALUES ('3', 'Ryan678cool', 'http://www.habbo.com/habbo-imaging/avatarimage?user=ryan678cool&action=std&direction=4&head_direction=3&gesture=sml&size=s&actio', '5 Gold Bars for official competitions');
INSERT INTO `donators` VALUES ('4', 'purplepetals:', 'http://www.habbo.com/habbo-imaging/avatarimage?user=purplepetals:&action=std&direction=4&head_direction=3&gesture=sml&size=s&actio', '1 Gold Bar for the V1 Launch');
INSERT INTO `donators` VALUES ('5', 'DjAngelraiodDJ', 'http://www.habbo.com/habbo-imaging/avatarimage?user=DjAngelraiodDJ&action=std&direction=4&head_direction=3&gesture=sml&size=s&actio', 'Hosting / VBulletin license');
INSERT INTO `donators` VALUES ('6', 'oomgito40', 'http://www.habbo.com/habbo-imaging/avatarimage?user=oomgito40&action=std&direction=4&head_direction=3&gesture=sml&size=s&actio', 'his unreleased music for the radio');
INSERT INTO `donators` VALUES ('7', 'cotdog', 'http://www.habbo.com/habbo-imaging/avatarimage?user=cotdog&action=std&direction=4&head_direction=3&gesture=sml&size=s&actio', 'the rest of the money to pay for V1');
INSERT INTO `donators` VALUES ('8', 'songbabysim', 'http://www.habbo.com/habbo-imaging/avatarimage?user=songbabysim&action=std&direction=4&head_direction=3&gesture=sml&size=s&actio', 'furni for official events');
INSERT INTO `donators` VALUES ('9', 'jay-jay-scene.', 'http://www.habbo.com/habbo-imaging/avatarimage?user=jay-jay-scene.&action=std&direction=4&head_direction=3&gesture=sml&size=s&actio', 'furni for official events');
INSERT INTO `donators` VALUES ('10', 'angela650', 'http://www.habbo.com/habbo-imaging/avatarimage?user=angela650&action=std&direction=4&head_direction=3&gesture=sml&size=s&actio', 'furni for official events');
INSERT INTO `donators` VALUES ('11', 'tylerr!', 'http://www.habbo.com/habbo-imaging/avatarimage?user=tylerr!&action=std&direction=4&head_direction=3&gesture=sml&size=s&actio', 'his time to design and code part of V1');

-- ----------------------------
-- Table structure for `events`
-- ----------------------------
DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `day` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `host` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of events
-- ----------------------------
INSERT INTO `events` VALUES ('8', 'Bank Game.', '3', '19:00 GMT', 'PizzaAyeeBanned');
INSERT INTO `events` VALUES ('6', 'Heaven or Hell', '2', '23:00 GMT', 'songbabysim');
INSERT INTO `events` VALUES ('14', 'Cozzie Change', '1', '15:00 GMT', 'popwozza');
INSERT INTO `events` VALUES ('9', 'Heaven or Hell', '3', '21:00 GMT', 'songbabysim');
INSERT INTO `events` VALUES ('13', 'Mole Game', '5', '15:00 GMT', 'popwozza');
INSERT INTO `events` VALUES ('11', 'Cozzie Change', '3', '20:00 GMT', 'babyinq');
INSERT INTO `events` VALUES ('15', 'Mole Game', '3', '15:00 GMT', 'popwozza');
INSERT INTO `events` VALUES ('20', 'Fridge game.', '4', '18:00 GMT', 'PizzaAyeeBanned');
INSERT INTO `events` VALUES ('22', 'nervous game', '5', '17:00 GMT', 'PizzaAyeeBanned');
INSERT INTO `events` VALUES ('23', 'Big Brother', '5', '20:00 GMT', 'clara-pixie');
INSERT INTO `events` VALUES ('24', 'Fridge game', '5', '22:00 GMT', 'PizzaAyeeBanned');
INSERT INTO `events` VALUES ('25', 'Mole Game', '6', '20:00 GMT', 'popwozza');
INSERT INTO `events` VALUES ('26', 'Heaven or Hell', '6', '17:00 GMT', 'PizzaAyeeBanned');
INSERT INTO `events` VALUES ('27', 'Fridge Game', '6', '18:00 GMT', 'angela650');
INSERT INTO `events` VALUES ('28', 'Cozzie Change', '6', '21:00 GMT', 'popwozza');

-- ----------------------------
-- Table structure for `events_timetable`
-- ----------------------------
DROP TABLE IF EXISTS `events_timetable`;
CREATE TABLE `events_timetable` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `day` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `host` varchar(255) NOT NULL,
  `event` varchar(255) NOT NULL,
  `approved` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of events_timetable
-- ----------------------------

-- ----------------------------
-- Table structure for `events_types`
-- ----------------------------
DROP TABLE IF EXISTS `events_types`;
CREATE TABLE `events_types` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of events_types
-- ----------------------------
INSERT INTO `events_types` VALUES ('1', 'Banzai Mocha Races');
INSERT INTO `events_types` VALUES ('2', 'Beat The Beast');
INSERT INTO `events_types` VALUES ('3', 'Beat The Furni');
INSERT INTO `events_types` VALUES ('4', 'Bingo');
INSERT INTO `events_types` VALUES ('5', 'Bumper Cars');
INSERT INTO `events_types` VALUES ('6', 'Carnival');
INSERT INTO `events_types` VALUES ('7', 'Chain Game');
INSERT INTO `events_types` VALUES ('8', 'Chair Races');
INSERT INTO `events_types` VALUES ('9', 'Chase The Pod');
INSERT INTO `events_types` VALUES ('10', 'Civi Wars');
INSERT INTO `events_types` VALUES ('11', 'Costume Change');
INSERT INTO `events_types` VALUES ('12', 'Deal or No Deal');
INSERT INTO `events_types` VALUES ('13', 'Defend Your Pod');
INSERT INTO `events_types` VALUES ('14', 'DodgeBall');
INSERT INTO `events_types` VALUES ('15', 'Dont Get The Syringe');
INSERT INTO `events_types` VALUES ('16', 'Dont Get Trapped');
INSERT INTO `events_types` VALUES ('17', 'Dont Roll A Number');
INSERT INTO `events_types` VALUES ('18', 'Dont Roll A Six');
INSERT INTO `events_types` VALUES ('19', 'Dont Hit My Wall');
INSERT INTO `events_types` VALUES ('20', 'Escape');
INSERT INTO `events_types` VALUES ('21', 'Falling Furni');
INSERT INTO `events_types` VALUES ('22', 'Fastest Typer');
INSERT INTO `events_types` VALUES ('23', 'Follow The Yellow Brick Road');
INSERT INTO `events_types` VALUES ('24', 'Fridge game');
INSERT INTO `events_types` VALUES ('25', 'GAW');
INSERT INTO `events_types` VALUES ('26', 'Generate a word');
INSERT INTO `events_types` VALUES ('27', 'Giveaway');
INSERT INTO `events_types` VALUES ('28', 'Grab A Seat');
INSERT INTO `events_types` VALUES ('29', 'Guess The Password');
INSERT INTO `events_types` VALUES ('30', 'Guess The Person');
INSERT INTO `events_types` VALUES ('31', 'Heaven or Hell?');
INSERT INTO `events_types` VALUES ('32', 'Higher or lower');
INSERT INTO `events_types` VALUES ('33', 'Isolation');
INSERT INTO `events_types` VALUES ('34', 'Lucky Color');
INSERT INTO `events_types` VALUES ('35', 'Maze');
INSERT INTO `events_types` VALUES ('36', 'Melting Carpets');
INSERT INTO `events_types` VALUES ('37', 'Mixed Events');
INSERT INTO `events_types` VALUES ('38', 'Mocha Races');
INSERT INTO `events_types` VALUES ('39', 'Music Quiz');
INSERT INTO `events_types` VALUES ('40', 'Name The Artist');
INSERT INTO `events_types` VALUES ('41', 'Pod Races');
INSERT INTO `events_types` VALUES ('42', 'Pool Attack');
INSERT INTO `events_types` VALUES ('43', 'Quiz');
INSERT INTO `events_types` VALUES ('44', 'Roller Trap');
INSERT INTO `events_types` VALUES ('45', 'Shout it out');
INSERT INTO `events_types` VALUES ('46', 'Silent Stab');
INSERT INTO `events_types` VALUES ('47', 'Simon Says');
INSERT INTO `events_types` VALUES ('48', 'Sit on it to win It');
INSERT INTO `events_types` VALUES ('49', 'Snake');
INSERT INTO `events_types` VALUES ('50', 'Stab');
INSERT INTO `events_types` VALUES ('51', 'Team Bingo');
INSERT INTO `events_types` VALUES ('52', 'Team Trivia');
INSERT INTO `events_types` VALUES ('53', 'Team Trivia Races');
INSERT INTO `events_types` VALUES ('54', 'Telephrase');
INSERT INTO `events_types` VALUES ('55', 'Telephrase Escape');
INSERT INTO `events_types` VALUES ('56', 'Time Challenge');
INSERT INTO `events_types` VALUES ('57', 'Trivia');
INSERT INTO `events_types` VALUES ('58', 'Wired Maze');

-- ----------------------------
-- Table structure for `jobapps`
-- ----------------------------
DROP TABLE IF EXISTS `jobapps`;
CREATE TABLE `jobapps` (
  `id` int(11) NOT NULL,
  `habbo` int(11) NOT NULL,
  `skype` int(11) NOT NULL,
  `zone` int(11) NOT NULL,
  `job` int(11) NOT NULL,
  `about` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of jobapps
-- ----------------------------

-- ----------------------------
-- Table structure for `logs`
-- ----------------------------
DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `id` int(225) NOT NULL AUTO_INCREMENT,
  `username` varchar(225) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `date` varchar(225) NOT NULL,
  `status` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=680 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of logs
-- ----------------------------


-- ----------------------------
-- Table structure for `love`
-- ----------------------------
DROP TABLE IF EXISTS `love`;
CREATE TABLE `love` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `dj` int(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `stamp` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of love
-- ----------------------------

-- ----------------------------
-- Table structure for `menu`
-- ----------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `url` varchar(255) NOT NULL,
  `resource` varchar(255) NOT NULL,
  `usergroup` varchar(255) NOT NULL,
  `protected` varchar(255) NOT NULL,
  `weight` int(255) NOT NULL,
  `hidden` varchar(250) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=112 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of menu
-- ----------------------------
INSERT INTO `menu` VALUES ('1', 'Add menu item', 'admin.addMenu', '_res/admin/addMenu.php', '6', '0', '1', '0');
INSERT INTO `menu` VALUES ('2', 'Manage menu items', 'admin.manageMenus', '_res/admin/manageMenus.php', '6', '0', '2', '0');
INSERT INTO `menu` VALUES ('41', 'Homepage', 'core.home', '_res/core/home.php', '1', '0', '0', '0');
INSERT INTO `menu` VALUES ('4', 'Staff Rules', 'core.panelRules', '_res/core/panelRules.php', '1', '0', '2', '0');
INSERT INTO `menu` VALUES ('69', 'Issue A Warning', 'headdj.warnDJ', '_res/headdj/warnDJ.php', '7', '0', '2', '0');
INSERT INTO `menu` VALUES ('10', 'Log Out', 'core.logout', '_res/core/logout.php', '1', '0', '8', '0');
INSERT INTO `menu` VALUES ('11', 'View requests', 'radio.requests', '_res/radio/requests.php', '2', '0', '2', '0');
INSERT INTO `menu` VALUES ('81', 'Edit Habbo Name', 'core.changehabbo', '_res/core/changeHabbo.php', '1', '0', '2', '0');
INSERT INTO `menu` VALUES ('13', 'Book timetable slot', 'guestradio.timetable', '_res/radio/timetable.php', '3', '0', '4', '0');
INSERT INTO `menu` VALUES ('14', 'Connection information', 'radio.connection', '_res/radio/connection.php', '2', '0', '6', '0');
INSERT INTO `menu` VALUES ('20', 'Create Staff Account', 'mgmt.addUser', '_res/mgmt/addUser.php', '4', '0', '1', '0');
INSERT INTO `menu` VALUES ('21', 'Manage Staff Account(s)', 'mgmt.manageUsers', '_res/mgmt/manageUsers.php', '4', '0', '2', '0');
INSERT INTO `menu` VALUES ('30', 'Connection information', 'admin.changeConnection', '_res/admin/changeConnection.php', '5', '0', '17', '0');
INSERT INTO `menu` VALUES ('62', 'Manage deletes', 'admin.manageDeletes', '_res/admin/manageDeletes.php', '5', '0', '19', '0');
INSERT INTO `menu` VALUES ('37', 'Add perm show', 'mgmt.addPermShow', '_res/mgmt/addPermShow.php', '4', '0', '11', '0');
INSERT INTO `menu` VALUES ('38', 'Manage perm shows', 'mgmt.managePermShows', '_res/mgmt/managePermShows.php', '4', '0', '12', '0');
INSERT INTO `menu` VALUES ('57', 'Announcements', 'admin.addAnnouncement', '_res/admin/addAnnouncement.php', '5', '0', '13', '0');
INSERT INTO `menu` VALUES ('108', 'File Uploader', 'seniorgraphics.imageUploader', '_res/seniorgraphics/imageUploader.php', '12', '0', '1', '0');
INSERT INTO `menu` VALUES ('67', 'Alert Website', 'admin.siteAlert', '_res/admin/siteAlert.php', '5', '0', '3', '0');
INSERT INTO `menu` VALUES ('68', 'Kick The DJ', 'headdj.kickDJ', '_res/headdj/kickDJ.php', '7', '0', '1', '0');
INSERT INTO `menu` VALUES ('60', 'Timetable converter', 'radio.converter', '_res/radio/converter.php', '2', '0', '4', '0');
INSERT INTO `menu` VALUES ('77', 'Logs', 'admin.logs', '_res/admin/logs.php', '6', '0', '23', '0');
INSERT INTO `menu` VALUES ('70', 'View My Warnings', 'radio.myWarnings', '_res/radio/myWarnings.php', '2', '0', '7', '0');
INSERT INTO `menu` VALUES ('72', 'Update DDOS Mode', 'admin.ddos', '_res/admin/ddos.php', '5', '0', '20', '0');
INSERT INTO `menu` VALUES ('73', 'View Job Applications', 'mgmt.jobApps', '_res/mgmt/jobApps.php', '6', '0', '13', '0');
INSERT INTO `menu` VALUES ('74', 'View DJ Reviews', 'mgmt.djReviews', '_res/mgmt/djReviews.php', '6', '0', '14', '0');
INSERT INTO `menu` VALUES ('75', 'View Contact Us', 'admin.contactUs', '_res/admin/contactUs.php', '5', '0', '21', '0');
INSERT INTO `menu` VALUES ('76', 'Allow Connection Information', 'headdj.allowInfo', '_res/headdj/allowInfo.php', '7', '0', '3', '0');
INSERT INTO `menu` VALUES ('78', 'Tasks', 'admin.tasks', '_res/admin/personalTasks.php', '5', '0', '22', '0');
INSERT INTO `menu` VALUES ('79', 'Tasks', 'mgmt.tasks', '_res/mgmt/personalTasks.php', '4', '0', '15', '0');
INSERT INTO `menu` VALUES ('85', 'Book a Slot', 'radio.timetable', '_res/radio/timetable.php', '2', '0', '8', '0');
INSERT INTO `menu` VALUES ('86', 'Timetable Converter', 'guestradio.converter', '_res/radio/converter.php', '3', '0', '5', '0');
INSERT INTO `menu` VALUES ('87', 'Connection Information', 'guestradio.connection', '_res/radio/connection.php', '3', '0', '6', '0');
INSERT INTO `menu` VALUES ('88', 'View My Warnings', 'guestradio.myWarnings', '_res/radio/myWarnings.php', '3', '0', '7', '0');
INSERT INTO `menu` VALUES ('91', 'DJ Says (NotInUse)', 'radio.djSays', '_res/radio/djSays.php', '16', '0', '9', '0');
INSERT INTO `menu` VALUES ('107', 'Mod CP Information', 'mod.modcp', '_res/mod/modcp.php', '14', '0', '1', '0');
INSERT INTO `menu` VALUES ('106', 'File Uploader', 'graphics.imageUploader', '_res/graphics/imageUploader.php', '11', '0', '1', '0');
INSERT INTO `menu` VALUES ('96', 'Manage Events', 'seniorevents.manageEvents', '_res/seniorevents/manageEvents.php', '8', '0', '4', '0');
INSERT INTO `menu` VALUES ('99', 'Manage Usergroups', 'admin.manageUsergroups', '_res/admin/manageUsergroups.php', '6', '0', '26', '0');
INSERT INTO `menu` VALUES ('98', 'Add Usergroup', 'admin.addUsergroup', '_res/admin/addUsergroup.php', '6', '0', '25', '0');
INSERT INTO `menu` VALUES ('100', 'Book an Event', 'events.addEvent.php', '_res/events/addEvent.php', '9', '0', '1', '0');
INSERT INTO `menu` VALUES ('103', 'Recent Songs', 'radio.recentSongs', '_res/radio/recentSongs.php', '2', '0', '10', '0');
INSERT INTO `menu` VALUES ('104', 'Recent Songs', 'guestdj.recentSongs', '_res/guestdj/recentSongs.php', '3', '0', '8', '0');
INSERT INTO `menu` VALUES ('105', 'Shoutcast Login', 'headdj.shoutcastLoginInformation', '_res/headdj/shoutcastLoginInformation.php', '7', '0', '4', '0');
INSERT INTO `menu` VALUES ('109', 'Change Password', 'user.changePassword', '_res/core/changePassword.php', '1', '0', '7', '0');
INSERT INTO `menu` VALUES ('110', 'Change DJ Name', 'radio.changedjname', '_res/core/changeDJName.php', '2', '0', '11', '0');
INSERT INTO `menu` VALUES ('111', 'Post Admin Update', 'update.postAdminUpdate', '_res/admin/adminUpdate.php', '5', '0', '23', '0');

-- ----------------------------
-- Table structure for `mgmt_messages`
-- ----------------------------
DROP TABLE IF EXISTS `mgmt_messages`;
CREATE TABLE `mgmt_messages` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `message` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of mgmt_messages
-- ----------------------------

-- ----------------------------
-- Table structure for `news`
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `desc` text NOT NULL,
  `article` text NOT NULL,
  `author` varchar(255) NOT NULL,
  `stamp` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of news
-- ----------------------------

-- ----------------------------
-- Table structure for `news_categories`
-- ----------------------------
DROP TABLE IF EXISTS `news_categories`;
CREATE TABLE `news_categories` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `admin` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of news_categories
-- ----------------------------
INSERT INTO `news_categories` VALUES ('1', 'Site News', '1');

-- ----------------------------
-- Table structure for `points_average`
-- ----------------------------
DROP TABLE IF EXISTS `points_average`;
CREATE TABLE `points_average` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `fifteen` varchar(255) NOT NULL,
  `thirty` varchar(255) NOT NULL,
  `fourtyfive` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of points_average
-- ----------------------------
INSERT INTO `points_average` VALUES ('1', '4', '4', '4');

-- ----------------------------
-- Table structure for `points_log`
-- ----------------------------
DROP TABLE IF EXISTS `points_log`;
CREATE TABLE `points_log` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `team` varchar(255) NOT NULL,
  `points` int(255) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of points_log
-- ----------------------------
INSERT INTO `points_log` VALUES ('1', 'EU', '5', 'Testing the feature.', '01-10-2013', 'Fun');
INSERT INTO `points_log` VALUES ('2', 'EU', '-5', 'Testing remove', '01-10-2013', 'Fun');

-- ----------------------------
-- Table structure for `profile`
-- ----------------------------
DROP TABLE IF EXISTS `profile`;
CREATE TABLE `profile` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `favsong` varchar(255) NOT NULL,
  `about` mediumtext NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `joined` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of profile
-- ----------------------------

-- ----------------------------
-- Table structure for `radio_timetable`
-- ----------------------------
DROP TABLE IF EXISTS `radio_timetable`;
CREATE TABLE `radio_timetable` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `day` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `dj` varchar(255) NOT NULL,
  `perm` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of radio_timetable
-- ----------------------------

-- ----------------------------
-- Table structure for `request_types`
-- ----------------------------
DROP TABLE IF EXISTS `request_types`;
CREATE TABLE `request_types` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `colour` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of request_types
-- ----------------------------
INSERT INTO `request_types` VALUES ('1', 'Request', 'cc0000');
INSERT INTO `request_types` VALUES ('2', 'Shoutout', 'ff6600');
INSERT INTO `request_types` VALUES ('3', 'Joke', 'aa00ff');
INSERT INTO `request_types` VALUES ('4', 'Competition', '00cc00');

-- ----------------------------
-- Table structure for `requests`
-- ----------------------------
DROP TABLE IF EXISTS `requests`;
CREATE TABLE `requests` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `for` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `stamp` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=85 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of requests
-- ----------------------------
INSERT INTO `requests` VALUES ('69', '1', '25', 'PizzaAyeeBanned', 'Halsey - Gasoline.', '1458669540', '82.36.204.62');
INSERT INTO `requests` VALUES ('71', '1', '35', 'EddieO.O', 'Could you play Perfect by Selena Gomez or Selena Gomez The Heart Wants What It Wants', '1458688904', '64.121.135.232');
INSERT INTO `requests` VALUES ('72', '1', '35', 'dereksotoba', 'what do you mean Justin Bieber', '1458689145', '97.103.110.245');

-- ----------------------------
-- Table structure for `sessions`
-- ----------------------------
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `stamp` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=797 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of sessions
-- ----------------------------


-- ----------------------------
-- Table structure for `settings`
-- ----------------------------
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `name` varchar(1000) NOT NULL,
  `value` varchar(1000) NOT NULL,
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of settings
-- ----------------------------
INSERT INTO `settings` VALUES ('stats', '1');
INSERT INTO `settings` VALUES ('panel_maint', '0');
INSERT INTO `settings` VALUES ('points', '1');
INSERT INTO `settings` VALUES ('stats_issue_level', '0');
INSERT INTO `settings` VALUES ('site_maint', '0');
INSERT INTO `settings` VALUES ('news_comments', '1');
INSERT INTO `settings` VALUES ('version', '1.0.0 (Build 1 - BETA 1) | Built on: 09/03/2016 16:19 BST');

-- ----------------------------
-- Table structure for `shoutbox`
-- ----------------------------
DROP TABLE IF EXISTS `shoutbox`;
CREATE TABLE `shoutbox` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `userid` int(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `time` int(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `me` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of shoutbox
-- ----------------------------

-- ----------------------------
-- Table structure for `shoutboxnotice`
-- ----------------------------
DROP TABLE IF EXISTS `shoutboxnotice`;
CREATE TABLE `shoutboxnotice` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `message` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of shoutboxnotice
-- ----------------------------

-- ----------------------------
-- Table structure for `site_alerts`
-- ----------------------------
DROP TABLE IF EXISTS `site_alerts`;
CREATE TABLE `site_alerts` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `author` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of site_alerts
-- ----------------------------

-- ----------------------------
-- Table structure for `spy`
-- ----------------------------
DROP TABLE IF EXISTS `spy`;
CREATE TABLE `spy` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `host` varchar(255) NOT NULL,
  `port` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of spy
-- ----------------------------
INSERT INTO `spy` VALUES ('1', 'http://sc.thishabbo.com', '8080', 'Thishabbo');
INSERT INTO `spy` VALUES ('2', 'http://habbcrazy.net', '8000', 'HabbCrazy');
INSERT INTO `spy` VALUES ('3', 'http://sc.hffm.co.uk', '8080', 'HFFM');
INSERT INTO `spy` VALUES ('5', 'http://37.130.230.38', '9998', 'Habbox');
INSERT INTO `spy` VALUES ('6', 'http://106.187.89.145', '8000', 'HabboHut');

-- ----------------------------
-- Table structure for `system`
-- ----------------------------
DROP TABLE IF EXISTS `system`;
CREATE TABLE `system` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sitename` varchar(255) NOT NULL,
  `siteurl` varchar(255) NOT NULL,
  `panelurl` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of system
-- ----------------------------
INSERT INTO `system` VALUES ('1', '', 'http://.net', 'http://');

-- ----------------------------
-- Table structure for `timetable`
-- ----------------------------
DROP TABLE IF EXISTS `timetable`;
CREATE TABLE `timetable` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `day` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `dj` varchar(255) NOT NULL,
  `perm` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=701 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of timetable
-- ----------------------------


-- ----------------------------
-- Table structure for `update_types`
-- ----------------------------
DROP TABLE IF EXISTS `update_types`;
CREATE TABLE `update_types` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `colour` varchar(255) NOT NULL,
  `permissions` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of update_types
-- ----------------------------
INSERT INTO `update_types` VALUES ('1', 'Radio Update', '51c833', 'radio');
INSERT INTO `update_types` VALUES ('2', 'Events Update', '4177b4', 'events');
INSERT INTO `update_types` VALUES ('3', 'Site Update', '2b2a2a', 'developer');
INSERT INTO `update_types` VALUES ('4', 'Jobs Update', '834099', 'management');
INSERT INTO `update_types` VALUES ('5', 'Admin Update', 'df3935', 'admin');
INSERT INTO `update_types` VALUES ('6', 'Radio Update', '51c833', 'management');
INSERT INTO `update_types` VALUES ('7', 'Events Update', '4177b4', 'management');

-- ----------------------------
-- Table structure for `updates`
-- ----------------------------
DROP TABLE IF EXISTS `updates`;
CREATE TABLE `updates` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(255) NOT NULL,
  `ip_addr` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `stamp` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of updates
-- ----------------------------


-- ----------------------------
-- Table structure for `user_feed`
-- ----------------------------
DROP TABLE IF EXISTS `user_feed`;
CREATE TABLE `user_feed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_feed
-- ----------------------------

-- ----------------------------
-- Table structure for `usergroups`
-- ----------------------------
DROP TABLE IF EXISTS `usergroups`;
CREATE TABLE `usergroups` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `colour` varchar(255) NOT NULL,
  `weight` int(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of usergroups
-- ----------------------------
INSERT INTO `usergroups` VALUES ('5', 'Admin', 'D61616', '99', 'i-locked');
INSERT INTO `usergroups` VALUES ('1', 'Home', '333333', '1', 'i-home');
INSERT INTO `usergroups` VALUES ('2', 'Radio DJ', '2473BA', '2', 'i-music');
INSERT INTO `usergroups` VALUES ('4', 'Management', '33AA00', '98', 'i-group');
INSERT INTO `usergroups` VALUES ('6', 'Senior Admin', 'D61616', '100', 'i-locked');
INSERT INTO `usergroups` VALUES ('7', 'Head DJ', 'A92D69', '4', 'i-headphones');
INSERT INTO `usergroups` VALUES ('8', 'Senior Events', 'A92D69', '6', 'i-pacman-ghost');
INSERT INTO `usergroups` VALUES ('9', 'Events Host', '2473BA', '5', 'i-pacman-ghost');
INSERT INTO `usergroups` VALUES ('11', 'Graphics Artist', '333333', '8', 'i-pencil');
INSERT INTO `usergroups` VALUES ('12', 'Snr Graphics', '33333', '9', 'i-pencil');
INSERT INTO `usergroups` VALUES ('13', 'Developer', '333333', '11', 'i-cog');
INSERT INTO `usergroups` VALUES ('14', 'Moderator', '333333', '10', 'i-alert');
INSERT INTO `usergroups` VALUES ('16', 'Site Owner', 'FF3D3D', '101', 'i-locked');
INSERT INTO `usergroups` VALUES ('17', 'Perm Shows', '2473BA', '102', 'mws-i-24 i-headphones');
INSERT INTO `usergroups` VALUES ('18', 'Reporter', '0267c0', '97', 'i-mail');

-- ----------------------------
-- Table structure for `users`
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `habbo` varchar(255) NOT NULL,
  `role` varchar(225) NOT NULL,
  `displaygroup` varchar(255) NOT NULL,
  `usergroups` varchar(255) NOT NULL,
  `deleteid` int(1) NOT NULL,
  `deleteuser` varchar(255) NOT NULL,
  `love` int(255) NOT NULL DEFAULT '0',
  `staff_points` int(255) NOT NULL DEFAULT '0',
  `viewed_info` int(1) NOT NULL DEFAULT '0',
  `joindate` varchar(255) NOT NULL DEFAULT '0',
  `djname` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('1', 'Skye', '40179f2a2515cfab6b3b91aa519e603b', 'Not', 'Site Owner', '16', '5,1,2,4,6,7,8,9,11,12,13,14,16,17,', '0', '', '7', '0', '1', '1458152812', 'Skye');

-- ----------------------------
-- Table structure for `warnings`
-- ----------------------------
DROP TABLE IF EXISTS `warnings`;
CREATE TABLE `warnings` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dj` varchar(255) NOT NULL,
  `is_read` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of warnings
-- ----------------------------
